README - SimpleSDIPlayer

SimpleSDIPlayer is a sample application that demonstrates how to display QuickTime movies
using the SDI (single document interface).

Enjoy,
QuickTime Team

