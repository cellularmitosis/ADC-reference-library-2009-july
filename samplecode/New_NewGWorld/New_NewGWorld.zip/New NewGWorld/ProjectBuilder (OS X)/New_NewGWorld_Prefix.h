//
// Prefix header for all source files of the 'New NewGWorld' target in the 'New NewGWorld' project.
//

#include <Carbon/Carbon.h>
