#!/bin/sh

NAME=`expr "$1" '|' "Untitled"`
echo "The chosen name was $NAME"

