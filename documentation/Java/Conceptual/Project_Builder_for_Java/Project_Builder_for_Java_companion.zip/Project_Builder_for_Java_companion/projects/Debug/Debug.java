//
//  Debug.java
//  Debug
//
import java.util.*;

public class Debug {
    
    public static void main (String args[]) {
        System.out.println("<Debug.main> Hello, World!");
        
        int a_number = 1;
        int another_number = 10;
        
        method(a_number, another_number);
        
        System.out.println("<Debug.main> a_number = " + a_number);
        System.out.println("<Debug.main> another_number = " + another_number);
    }
    
    public static void method(int number1, int number2) {
        Person person = new Person("Kathy", "Yates", "female", "brown");
        String a_string = person.firstName() + " likes debugging code.";
        System.out.println("<Debug.method> person = " + person);
    }
}
