//
//  PixelTypes.m
//  Image Difference
//
//  Created by John C. Randolph on Wed Jan 22 2003.
//  Copyright (c) 2003 Apple Computer, Inc.. All rights reserved.
//

#import "PixelTypes.h"


@implementation PixelTypes

@end
