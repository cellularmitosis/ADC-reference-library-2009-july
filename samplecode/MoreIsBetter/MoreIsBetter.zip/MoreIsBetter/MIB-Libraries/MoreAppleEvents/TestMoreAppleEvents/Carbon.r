/*
 *  Permit this Carbon application to launch on OS X
 *
 *  Copyright � 1997-2001 Metrowerks Corporation
 *
 *  Questions and comments to:
 *       <mailto:support@metrowerks.com>
 *       <http://www.metrowerks.com/>
 */



/*----------------------------carb � Carbon on OS X launch information --------------------------*/
type 'carb' {
};


resource 'carb'(0) {
};