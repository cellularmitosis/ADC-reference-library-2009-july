#import <Cocoa/Cocoa.h>

@interface Converter : NSObject {

	float sourceCurrencyAmount;
	float rate;

}

@property(readwrite) float sourceCurrencyAmount, rate;

- (float)convertCurrency;

@end
