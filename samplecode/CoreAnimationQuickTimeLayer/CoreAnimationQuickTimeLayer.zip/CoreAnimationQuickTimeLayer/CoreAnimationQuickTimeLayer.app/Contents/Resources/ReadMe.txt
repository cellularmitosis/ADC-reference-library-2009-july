CoreAnimationQuickTimeLayer
v1.0

This sample code demonstrates how to use Core Animation on Mac OS X 10.5 together with QuickTime and a visual context. For some eye-candy, it shows some funky frequency level indicators, along with (optionally) a foreground filter ("Bloom") and background filter ("Kaleidoscope").

When launched the first time, the app will ask for a movie that has some audio (otherwise the frequency levels won't work).