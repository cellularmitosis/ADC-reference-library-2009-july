

package my.ejb;

import java.rmi.RemoteException;

public interface Person extends javax.ejb.EJBObject {

  /**
   *
   * @throws java.rmi.RemoteException
   */
  public java.lang.String getPersonName() throws RemoteException;

  /**
   *
   * @throws java.rmi.RemoteException
   */
  public void setPersonName(java.lang.String personName) throws RemoteException;

  /**
   *
   * @throws java.rmi.RemoteException
   */
  public java.lang.Integer getPerson_ID() throws RemoteException;

}
