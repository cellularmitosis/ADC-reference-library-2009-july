To use Xcode Audio Unit templates:

    (1) Copy the Audio_Units directory to "~/Library/Application\ Support/Apple/Developer\ Tools/Project\ Templates".  If the "Project Templates" directory does not exist, create it. This will create templates for the current user.  To make these Templates available to all users copy Audio_Units directory to "/Library/Application\ Support/Apple/Developer\ Tools/Project\ Templates/".

    (2) Launch Xcode.

    (3) Start "New Project"


If installed correctly Audio Unit templates should appear in Assistant window.

