

package my.ejb;

import java.rmi.RemoteException;
import javax.ejb.*;
import javax.naming.*;

public class PersonCMP implements EntityBean {
  protected EntityContext _entityContext;

  
  /**
   *
   */ 
  public java.lang.String personName;
  
  /**
   *
   */ 
  public java.lang.Integer person_ID;
  

  /**
   * Empty constructor as required by the EJB spcification
   */
  public PersonCMP() {
  }

 
  /**
   * This method creates a new entity from its required attributes
   */
  public java.lang.Integer ejbCreate(java.lang.Integer person_ID) throws CreateException {
     this.person_ID = person_ID;
     
     return null;
  }

  /**
   * 
   */
  public void ejbPostCreate(java.lang.Integer person_ID) {
  }


  /**
   * This method creates a new entity from all attributes
   */
  public java.lang.Integer ejbCreate(java.lang.Integer person_ID, java.lang.String personName) throws  CreateException{
     this.personName = personName;
     this.person_ID = person_ID;
     
     return null;
  }

  /**
   * 
   */
  public void ejbPostCreate(java.lang.Integer person_ID, java.lang.String personName) {
  }



  /**
   *
   */
  public java.lang.String getPersonName(){
    return personName;
  }

  /**
   *
   */
  public void setPersonName(java.lang.String personName){
    this.personName = personName;
  }

  /**
   *
   */
  public java.lang.Integer getPerson_ID(){
    return person_ID;
  }


  public void ejbRemove() throws RemoveException {
  }

  public void ejbActivate() {
  }

  public void ejbPassivate() {
  }

  public void ejbLoad() {
  }

  public void ejbStore() {
  }

  public void setEntityContext(EntityContext entityContext) {
    _entityContext = entityContext;
  }

  public void unsetEntityContext() {
    _entityContext = null;
  }
}
