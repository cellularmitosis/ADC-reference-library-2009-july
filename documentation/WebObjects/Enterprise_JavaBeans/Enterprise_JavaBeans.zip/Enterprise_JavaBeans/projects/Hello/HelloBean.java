package my.ejb;

import javax.ejb.*;

public class HelloBean implements SessionBean {


    //
    // Creation methods
    //

    public HelloBean() {
    }

    public void ejbCreate() throws CreateException {
        /* Stateless session bean create methods never have parameters */
    }


    //
    // SessionBean interface implementation
    //

    private SessionContext _ctx;

    public void setSessionContext(SessionContext ctx) {
        this._ctx = ctx;
    }


    public void ejbPassivate() {

        /* does not apply to stateless session beans */
    }

    public void ejbActivate() {

        /* does not apply to stateless session beans */
    }

    public void ejbRemove() {
    }


    //
    // Business Logic Implementations
    //

    // Example:
    // public String hello() { return "hello"; }

    public String message() {
        return "Hello, World.";
    }
}