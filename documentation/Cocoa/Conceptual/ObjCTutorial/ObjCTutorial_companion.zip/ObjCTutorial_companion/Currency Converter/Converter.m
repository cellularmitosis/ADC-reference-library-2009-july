#import "Converter.h"

@implementation Converter
@synthesize sourceCurrencyAmount, rate;

- (float)convertCurrency {
	return self.sourceCurrencyAmount * self.rate;
}

@end
