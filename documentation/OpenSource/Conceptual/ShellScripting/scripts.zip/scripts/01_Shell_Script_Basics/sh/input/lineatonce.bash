#!/bin/bash
IFS="
"
read LINE A
echo "Line was \"$LINE\"."
