README - MakeEffectSlideShow

This application takes the video tracks from two or more movies, asks 
the user to select a 2-source effect, and makes a slide show movie 
which uses the effect to switch from one video track to the next. 

Short video tracks are scaled up to a minimum length, and we can import
all sorts of graphical image formats as movies, so you can use this to 
generate a slide show movie from still images -- or even a collection
of stills and movies.

Enjoy,
QuickTime Team

