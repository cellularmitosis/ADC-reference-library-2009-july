//
// Application.java
// Project Serialization
//
// Created by The_Mole.
//

import com.webobjects.foundation.*;
import com.webobjects.foundation.xml.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class Application extends WOApplication {
    
    public static void main(String argv[]) {
        WOApplication.main(argv, Application.class);
    }

    public Application() {
        super();
        System.out.println("Welcome to " + this.name() + "!");

	// Serialize an array.
	arraySerialization();
        
	// Serialize primitive values.
	primitiveSerialization();
	
	// Serialize a Movie object.
	movieSerialization();
	
	// Serialize an array of Movie objects.
	movieArraySerialization();
    }

    /**
     * Creates and serializes an NSArray of Strings.
     * @param identifier   identifies the target file, without a
     *                     path or an extension (for example, "BookTitles")
     */
    public void serializeArray(String identifier) {
        // Instantiate object to serialize.
        NSArray book_titles =  new NSArray(new Object[] {"The Chestry Oak", "A Tree for Peter", "The White Stag"});
    
        // Serialize the object.
        XMLSerializer.serializeObject(book_titles, identifier);
    }
    
    /**
     * Deserializes an NSArray and writes its contents to the console.
     * @param identifier   identifies the source file, without a
     *                     path or an extension
     */
    public void deserializeArray(String identifier) {
        // Deserialize the data and assign it to an NSArray object.
        NSArray books = (NSArray)XMLSerializer.deserializeObject(identifier);
    
        // Display the contents of <code>books</code> on the console
        // (the Run pane in Project Buider).
        System.out.println("");
        System.out.println("** Deserialized NSArray **");
        System.out.println(books);
        System.out.println("");
    }

    /**
     * Invokes the <code>serializeArray</code> and
     * <code>deserializeArray</code> methods.
     */
    public void arraySerialization() {
	String identifier = "BookTitles";

	// Serialize NSArray object.
	serializeArray(identifier);

	// Deserialize NSArray object.
	deserializeArray(identifier);
    }
    
    /**
     * Serializes a set of primitive values.
     *
     * @param filename    identifies the target file, including its
     *                    path and extension
     *
     * @param an_int      value to serialize
     * @param a_boolean   value to serialize
     * @param a_char      value to serialize
     * @param a_double    value to serialize
     */
    public void serializePrimitives(String filename, int an_int, boolean a_boolean, char a_char, double a_double) {
	try {
	    // Open an output stream.
	    NSXMLOutputStream stream = XMLSerializer.openOutputStream(filename, null);

	    // Write values.
	    stream.writeInt(an_int, "my_integer");
	    stream.writeBoolean(a_boolean, "my_boolean");
	    stream.writeChar(a_char, "my_char");
	    stream.writeDouble(a_double, "my_double");

	    // Close the stream.
	    XMLSerializer.closeStream(filename);
	}

	catch (IOException e) {
	    e.printStackTrace();
	}
    }

    /**
     * Deserializes a set of primitive values.
     *
     * @param filename   identifies the source file, including its
     *                   path and extension
     */
    public void deserializePrimitives(String filename) {
	try {
	    // Open an input stream.
	    NSXMLInputStream stream = XMLSerializer.openInputStream(filename);

	    // Read values.
	    int the_int = stream.readInt();
	    boolean the_boolean = stream.readBoolean();
	    char the_char = stream.readChar();
	    double the_double = stream.readDouble();

	    XMLSerializer.closeStream(filename);

	    // Write values to console (Run pane in Project Builder).
	    System.out.println("");
	    System.out.println("** Deserialized primitives **");
	    System.out.println("int: " + the_int);
	    System.out.println("boolean: " + the_boolean);
	    System.out.println("char: " + the_char);
	    System.out.println("double: " + the_double);
	    System.out.println("");
	}

	catch (IOException e) {
	    e.printStackTrace();
	}
    }

    /**
     * Invokes the <code>serializePrimitives</code> and
     * <code>deserializePrimitives</code> methods.
     */
    public void primitiveSerialization() {
	String filename = "/tmp/PrimitiveValues_data.xml";

	// Serialize primitive values.
	serializePrimitives(filename, 5, true, 'u', 3.14);

	// Deserialize primitive values.
	deserializePrimitives(filename);
    }

    /**
     * Serializes a Movie object.
     *
     * @param identifier   identifies the target file, without a
     *                     a path or an extension
     */
    public void serializeMovie(String identifier) {
	// Set the local time zone.
	NSTimeZone timeZone = NSTimeZone.timeZoneWithName("America/Los_Angeles", true);

	Movie movie = new Movie("Alien", "20th Century Fox", new NSTimestamp(1979, 10, 25, 0, 0, 0, timeZone));

	XMLSerializer.serializeObject(movie, identifier);
    }

    /**
     * Deserializes Movie data into an object.
     *
     * @param identifier   identifies the source stream (a file) without a
     *                     a path or an extension (for example, "Movie")
     */
    public void deserializeMovie(String identifier) {
	Movie movie = (Movie)XMLSerializer.deserializeObject(identifier);

	System.out.println("");
	System.out.println("** Deserialized Movie object **");
	System.out.println(movie.toString());
	System.out.println("");
    }

    /**
     * Invokes the <code>movieSerialization</code> and
     * <code>movieDeserialization</code> methods.
     */
    public void movieSerialization() {
	String identifier = "Movie";

	serializeMovie(identifier);
	deserializeMovie(identifier);
    }
    
    /**
     * Serializes a Movie array.
     *
     * @param identifier   identifies the target file, without a
     *                     a path or an extension
     */
    public void serializeMovieArray(String identifier) {
	// Set the local time zone.
	NSTimeZone timeZone = NSTimeZone.timeZoneWithName("America/Los_Angeles", true);

	// Initialize the array.
	NSMutableArray movies = new NSMutableArray();
	movies.addObject(new Movie("Alien", "20th Century Fox", new NSTimestamp(1979, 10, 25, 0, 0, 0, timeZone)));
	movies.addObject(new Movie("Blade Runner", "Warner Brothers", new NSTimestamp(1982, 1, 3, 0, 0, 0, timeZone)));
	movies.addObject(new Movie("Star Wars", "20th Century Fox", new NSTimestamp(1977, 12, 29, 0, 0, 0, timeZone)));

	// Serialize the array.
	XMLSerializer.serializeObject(movies, identifier);
    }

    /**
     * Deserializes Movie data into an NSArray.
     *
     * @param identifier          identifies the source stream (a file) without a
     *                            a path or an extension (for example, "Movie")
     */
    public void deserializeMovieArray(String identifier) {
	// Create an empty array.
	NSArray movies = new NSArray();

	// Deserialize data into movies.
	movies = (NSArray)XMLSerializer.deserializeObject(identifier);

	System.out.println("");
	System.out.println("** Deserialized Movie array **");
	System.out.println(movies.toString());
	System.out.println("");
    }

    /**
     * Invokes the <code>movieArraySerialization</code> and
     * <code>movieArrayDeserialization</code> methods.
     */
    public void movieArraySerialization() {
	String identifier = "Movies";

	serializeMovieArray(identifier);
	deserializeMovieArray(identifier);
    }
}
