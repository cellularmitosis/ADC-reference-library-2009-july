// Student.java
// Created on Tue Aug 27 17:15:02 US/Pacific 2002 by Apple EOModeler Version 5.2

package businesslogic.server;

import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;
import java.math.BigDecimal;
import java.util.*;

public class Student extends EOGenericRecord {

    private static final double ACT_WEIGHT = 0.30;
    private static final double SAT_WEIGHT = 0.30;
    private static final double GPA_WEIGHT = 0.40; 

    public Student() {
        super();
    }

/*
    // If you implement the following constructor EOF will use it to
    // create your objects, otherwise it will use the default
    // constructor. For maximum performance, you should only
    // implement this constructor if you depend on the arguments.
    public Student(EOEditingContext context, EOClassDescription classDesc, EOGlobalID gid) {
        super(context, classDesc, gid);
    }

    // If you add instance variables to store property values you
    // should add empty implementions of the Serialization methods
    // to avoid unnecessary overhead (the properties will be
    // serialized for you in the superclass).
    private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
    }

    private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, java.lang.ClassNotFoundException {
    }
*/

    public String name() {
        return (String)storedValueForKey("name");
    }

    public void setName(String value) {
        takeStoredValueForKey(value, "name");
    }

    public Number gpa() {
        return (Number)storedValueForKey("gpa");
    }

    public void setGpa(Number value) {
        takeStoredValueForKey(value, "gpa");
    }

    public Number act() {
        return (Number)storedValueForKey("act");
    }

    public void setAct(Number value) {
        takeStoredValueForKey(value, "act");
    }

    public Number sat() {
        return (Number)storedValueForKey("sat");
    }

    public void setSat(Number value) {
        takeStoredValueForKey(value, "sat");
    }

    public NSTimestamp firstContact() {
        return (NSTimestamp)storedValueForKey("firstContact");
    }

    public void setFirstContact(NSTimestamp value) {
        takeStoredValueForKey(value, "firstContact");
    }

    public NSArray activities() {
        return (NSArray)storedValueForKey("activities");
    }

    public void setActivities(NSArray value) {
        takeStoredValueForKey(value, "activities");
    }

    public void addToActivities(businesslogic.server.Activity object) {
        includeObjectIntoPropertyWithKey(object, "activities");
    }

    public void removeFromActivities(businesslogic.server.Activity object) {
        excludeObjectFromPropertyWithKey(object, "activities");
    }
    
    public Number rating() {
 	float aggregate = 0;
 	float satTemp;
 	float actTemp;
 	float gpaTemp;
        
 	if (sat() != null && act() != null && gpa() !=null) {
 		satTemp = sat().floatValue() / 1600;
 		actTemp = act().floatValue() / 36;
 		gpaTemp = gpa().floatValue() / 4;
            
 		aggregate = (float)(((gpaTemp * GPA_WEIGHT) + (actTemp * ACT_WEIGHT) + (satTemp * SAT_WEIGHT)) * 10);
 	}
        
 	return (new Float(aggregate));
    }
    
    public Number clientSideRequestRating() {
        return rating();
    }
    
    public Number validateSat(Number score) throws NSValidation.ValidationException {
        if ((score.intValue() > 1600) || (score.intValue() < 0)) {
            throw new NSValidation.ValidationException("Invalid SAT score");
    }
    else
        return score;
    }
    
    public Number validateAct(Number score) throws NSValidation.ValidationException {
        if ((score.intValue() > 36) || (score.intValue() < 0)) {
		throw new NSValidation.ValidationException("Invalid ACT score");
	}
    else
        return score;        
    }
    
    public Number validateGpa(Number score) throws NSValidation.ValidationException {
 	if ((score.floatValue() > 4.0) || (score.floatValue() < 0.0)) {
		throw new NSValidation.ValidationException("Invalid GPA");
    }
    else
        return score;        
    }
    
    public void awakeFromInsertion(EOEditingContext context) {
        super.awakeFromInsertion(context);
        if (gpa() == null) {
            setGpa(new BigDecimal("0"));
        }
        if (sat() == null) {
            setSat(new BigDecimal("0"));
        }
        if (act() == null) {
            setAct(new BigDecimal("0"));
        }
        if (name() == null) {
            setName("");
        }
    }	

}
