//
//  Calculator.java
//


public class Calculator extends Object {

    public static double add(double addend1, double addend2) {
        double sum = addend1 + addend2;
        
        return sum;
    }

    public static double subtract(double minuend, double subtrahend) {
        double difference = minuend - subtrahend;
        
        return difference;
    }

    public static double multiply(double multiplicand1, double multiplicand2) {
        double product = multiplicand1 * multiplicand2;
        
        return product;
    }

    public static double divide(double dividend, double divisor) {	
        double quotient = dividend / divisor;
        
        return quotient;
    }
}
