//
//  AuthorClient.java
//  Authors_Client
//

import java.net.*;
import java.util.Enumeration;

import com.webobjects.eocontrol.*;
import com.webobjects.foundation.*;
import com.webobjects.webservices.client.*;
import com.webobjects.webservices.support.xml.WOStringKeyMap;

public class AuthorClient {

    /**
     * Object through which the Web service's operations are invoked.
     */
    private WOWebServiceClient _serviceClient = null;
    
    /**
     * Address for the Web service's WSDL document.
     */
    private String _service_address = "http://localhost:5220/cgi-bin/WebObjects/Authors.woa/ws/Author?wsdl";

    /**
     */
    public AuthorClient() {
        super();
    }

    /**
     * Adds a book and an author to the data store.
     * @param title            book's title;
     * @param authorLastName   last name of the author;
     * @param authorFirstName  first name of the author;
     * @return <code>true</code> when successful; <code>false</code> otherwise.
     */
    public boolean addBookForAuthor(String title, String authorLastName, String authorFirstName) {
        EOKeyGlobalID author_global_id = addAuthor(authorLastName, authorFirstName);
        addBook(title, author_global_id);
        return true;
    }

    /**
     * Adds an author to the data store.
     * @param authorLastName   last name of the book's author;
     * @param authorFirstName  first name of the book's author;
     * @return global ID of the corresponding enterprise object.
     */
    private EOKeyGlobalID addAuthor(String lastName, String firstName) {
        Object arguments[] = {lastName, firstName};
        Object[] result = (Object[])serviceClient().invoke(serviceName(), "addAuthor", arguments);
        WOStringKeyMap key_map = (WOStringKeyMap)result[0];
        EOKeyGlobalID author_global_id = (EOKeyGlobalID)key_map.valueForKey("globalID");
        return author_global_id;
    }
    
    /**
     * Adds a book to the data store.
     * @param title              book's title;
     * @param author_global_id   global ID of the enterprise object representing
     *                           the book's author;
     * @return <code>true</code> when successful; <code>false</code> otherwise.
     */
    private boolean addBook(String title, EOKeyGlobalID author_global_id) {
        Object arguments[] = {title, author_global_id};
        Object result = serviceClient().invoke(serviceName(), "addBook", arguments);
        return true;
    }
    
    /**
     * Obtains the Web service name.
     * Normally one WSDL file describes one Web service,
     * but it could describe one or more services.
     * @return Web service name.
     */
    public String serviceName() {
        return (String)serviceClient().serviceNames().objectAtIndex(0);
    }
    
    /**
     * Obtains an agent through which service operations are invoked.
     * @return service agent.
     */
    private WOWebServiceClient serviceClient() {
        if (_serviceClient == null) {
            _serviceClient = clientFromAddress(_service_address);
        }
        return _serviceClient;
    }
    
    /**
     * Obtains a Web service-client object through which
     * service operations can be invoked.
     * @return Web service-client object.
     */
    private static WOWebServiceClient clientFromAddress(String address) {
        WOWebServiceClient service_client = null;

        // Create the Web service's URL.
        URL url;
        try {
            url = new URL(address);
        }
        catch (MalformedURLException e) {
            url = null;
        }

        // Get a service-client object.
        service_client = new WOWebServiceClient(url);

        return service_client;
    }
}
