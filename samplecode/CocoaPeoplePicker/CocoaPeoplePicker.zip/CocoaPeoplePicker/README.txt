CocoaPeoplePicker
v1.0
12/8/2003

This sample demonstrates how to use the AddressBook framework's ABPeoplePickerView for Cocoa, new in Panther.  It embeds an ABPeoplePickerView in a window, and includes controls for view options and access to data the user has selected.

Take a look at MainMenu.nib and MyPeoplePickerController.m for how to hook an ABPeoplePickerView into your app and integrate with the Mac OS X Address Book.

The ABPeoplePickerView is new to Mac OS X 10.3 (Panther).  It requires 10.3 or later, and Xcode.