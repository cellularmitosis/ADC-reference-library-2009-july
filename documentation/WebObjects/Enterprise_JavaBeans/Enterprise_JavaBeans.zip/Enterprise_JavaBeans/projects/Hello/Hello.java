package my.ejb;

import javax.ejb.*;
import java.rmi.RemoteException;
import java.rmi.Remote;

public interface Hello extends EJBObject {

    //
    // Business Logic Interfaces
    //

    // Example:
    // public String hello() throws java.rmi.RemoteException;
    
    public String message() throws RemoteException;
    
}