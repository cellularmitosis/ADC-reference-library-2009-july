

package my.ejb;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.ejb.*;
import java.sql.*;

public class PersonBMP
implements EntityBean {
  protected DataSource _datasource;


  protected EntityContext _entityContext;

  
  /**
   *
   */ 
  protected java.lang.String personName;

  /**
   *
   */ 
  protected java.lang.Integer person_ID;



  /**
   * Empty constructor as required by the EJB spcification
   */
  public PersonBMP() {
  }

 
  /**
   * This method creates a new entity from all required (e.g. non-NULL) attributes
   * @throws javax.ejb.CreateException
   * @returns the primary key for this bean instance 
   */
  public java.lang.Integer ejbCreate(java.lang.Integer person_ID) throws CreateException{

    
    this.person_ID = person_ID;
    

    Connection connection=null;
    PreparedStatement statement=null;
    try{
      String sqlString = "INSERT INTO PERSON (PERSON_ID) VALUES (?)";
      connection = _datasource.getConnection();
      statement = connection.prepareStatement(sqlString);
      
      statement.setInt(1, person_ID.intValue());
      int ret=statement.executeUpdate();
      if ( ret != 1 ) {
        throw new CreateException();
      }
    }catch(SQLException e) {
      throw new EJBException(e);
    }finally {
      cleanup(connection, statement);
    }
    return person_ID;

  }

  /**
   * 
   */
  public void ejbPostCreate(java.lang.Integer person_ID) {

  }


  /**
   * This method creates a new entity from all attributes
   * @throws javax.ejb.CreateException
   * @returns the primary key for this bean instance 
   */
  public java.lang.Integer ejbCreate(java.lang.Integer person_ID, java.lang.String personName) throws CreateException {


    this.personName = personName;
    this.person_ID = person_ID;
    

    Connection connection=null;
    PreparedStatement statement=null;
    try{
      String sqlString = "INSERT INTO PERSON (PERSON_NAME, PERSON_ID) VALUES (?,?)";
      connection = _datasource.getConnection();
      statement = connection.prepareStatement(sqlString);
      
      statement.setString(1, personName);
      statement.setInt(2, person_ID.intValue());
      int ret=statement.executeUpdate();
      if (ret != 1 ) {
        throw new CreateException();
      }
     }catch(SQLException e) {
       throw new EJBException(e);
     }finally {
       cleanup(connection, statement);
     }
     return person_ID;


  }

  /**
   * 
   */
  public void ejbPostCreate(java.lang.Integer person_ID, java.lang.String personName) {

  }

 
  /**
   * This method returns all entities in this table
   * @returns all entities in the table in a java.util.Collection
   * @throws javax.ejb.FinderException if there are problems connecting to the database or executing the query
   */
  public java.util.Collection ejbFindAll() throws FinderException{

    Connection connection=null;
    PreparedStatement statement=null;
    try{
      String sqlString = "SELECT PERSON_ID FROM PERSON";
      connection = _datasource.getConnection();
      statement = connection.prepareStatement(sqlString);
      ResultSet resultSet = statement.executeQuery();
      java.util.Collection primaryKeys = new java.util.ArrayList();
      while(resultSet.next()) {
        java.lang.Integer primaryKey = new java.lang.Integer(resultSet.getInt(1));
        primaryKeys.add(primaryKey);
      }
      resultSet.close();
      return primaryKeys;
     }catch(SQLException e) {
       throw new EJBException(e);
     }finally {
       cleanup(connection, statement);
     }

  }


  /**
   * This method returns the bean associated with the primaryKey argument, or throws a javax.ejb.ObjectNotFoundException
   * @throws javax.ejb.ObjectNotFoundException if an entity with the given primary key doesn't exist
   * @returns the bean associated with the primaryKey argument
   */
  public java.lang.Integer ejbFindByPrimaryKey(java.lang.Integer primaryKey) throws FinderException{

    Connection connection=null;
    PreparedStatement statement=null;
    try{
      String sqlString = "SELECT PERSON_ID FROM PERSON WHERE PERSON_ID = ? ";
      connection = _datasource.getConnection();
      statement = connection.prepareStatement(sqlString);
      
      statement.setInt(1, primaryKey.intValue());
      ResultSet resultSet = statement.executeQuery();
      boolean found = resultSet.next();
      resultSet.close();
      if(found) {
        return primaryKey;
      } else {
        throw new ObjectNotFoundException("Could not find: " + primaryKey);
      }
     }catch(SQLException e) {
       throw new EJBException(e);
     }finally {
       cleanup(connection, statement);
     }

  }



  /**
   *
   */
  public java.lang.String getPersonName(){
    return personName;
  }

  /**
   *
   */
  public void setPersonName(java.lang.String personName){
    this.personName = personName;
  }

  /**
   *
   */
  public java.lang.Integer getPerson_ID(){
    return person_ID;
  }



  public void ejbRemove() throws RemoveException {

    Connection        connection = null;
    PreparedStatement statement  = null;

    try {
      String sqlString = "DELETE FROM PERSON WHERE PERSON_ID = ? ";
      connection = _datasource.getConnection();
      statement  = connection.prepareStatement(sqlString);
      
      statement.setInt(1, person_ID.intValue());
      if (statement.executeUpdate() != 1) {
        throw new RemoveException();
      }
    } catch (SQLException e) {
      throw new EJBException(e);
    } finally {
      cleanup(connection, statement);
    }

  }

  public void ejbActivate() {
    java.lang.Integer person_ID = (java.lang.Integer) _entityContext.getPrimaryKey();
    this.person_ID = person_ID;
    
  }

  public void ejbPassivate() {

  }

  public void ejbLoad() {

    Connection connection=null;
    PreparedStatement statement=null;
    try{
      String sqlString = "SELECT PERSON_NAME FROM PERSON WHERE PERSON_ID = ? ";
      connection = _datasource.getConnection();
      statement = connection.prepareStatement(sqlString);
      
      statement.setInt(1, person_ID.intValue());
      ResultSet resultSet = statement.executeQuery();
      if(!resultSet.next()) {
        resultSet.close();
        throw new NoSuchEntityException("ejbLoad failed. Primary key not found: "+_entityContext.getPrimaryKey());
      }
      
      personName = resultSet.getString(1);
      resultSet.close();
    }catch(SQLException e) {
      throw new EJBException(e);
    }finally {
      cleanup(connection, statement);
    }



  }

  public void ejbStore() {


    Connection connection=null;
    PreparedStatement statement=null;
    try{
      String sqlString = "UPDATE PERSON SET PERSON_NAME = ?  WHERE PERSON_ID = ? ";
      connection = _datasource.getConnection();
      statement = connection.prepareStatement(sqlString);
      
      statement.setString(1, personName);
      statement.setInt(2, person_ID.intValue());
      if(statement.executeUpdate()!=1) {
        throw new NoSuchEntityException("ejbStore failed. Primary key not found: "+_entityContext.getPrimaryKey());
      }
    }catch(SQLException e) {
      throw new EJBException(e);
    }finally {
      cleanup(connection, statement);
    }

  }

  public void setEntityContext(EntityContext entityContext) {


    _entityContext = entityContext;

    try{
      InitialContext context = new InitialContext();
      _datasource = (DataSource) context.lookup("java:comp/env/jdbc/DataSource");

    }catch(Exception ne) {
      throw new EJBException(ne);
    }
  }

  public void unsetEntityContext() {


    _entityContext = null;
  }


  private void cleanup(Connection connection, PreparedStatement statement) {
    if(statement!=null) {
      try{
        statement.close();
      }catch(SQLException e) {
      // we don't really care
      }
    }
    if(connection!=null) {
      try{
        connection.close();
      }catch(SQLException e) {
      // we don't really care
      }
    }
  }

}
