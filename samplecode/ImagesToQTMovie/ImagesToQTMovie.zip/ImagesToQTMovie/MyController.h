/*
 *  MyController.h
 *  ICADownloadFirst
 *
 *  Created by scottkue on Sun Nov 18 2001.
 *  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
 *
 */

#include <Carbon/Carbon.h>

