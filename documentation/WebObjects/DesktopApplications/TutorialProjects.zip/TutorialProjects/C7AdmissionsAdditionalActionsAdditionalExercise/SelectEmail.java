package admissions.client;

import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eogeneration.*;

public class SelectEmail extends Object{

    public SelectEmail() {
        super();
    }

    public NSArray selectEmailAddresses() {
        return EOControllerFactory.sharedControllerFactory().selectWithEntityName ("Email", true, false);
    }
}