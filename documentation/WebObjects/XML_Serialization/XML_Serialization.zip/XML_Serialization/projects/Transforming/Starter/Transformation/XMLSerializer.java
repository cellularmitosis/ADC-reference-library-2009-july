//
// XMLSerializer.java
// Project Transformation
//
// Created by The_Mole.
//

import com.webobjects.appserver.WOApplication;
import com.webobjects.appserver.WOResourceManager;
import com.webobjects.eocontrol.*;
import com.webobjects.foundation.*;
import com.webobjects.foundation.xml.*;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import javax.xml.transform.Transformer;

/*
 * Manages serialization and deserialization of objects
 * to and from XML files.
 */
public class XMLSerializer extends Object {
    /*
     * Encapsulates a file stream and an object stream (a channel).
     */
    private static class Channel {
        protected Object file_stream;
        protected Object object_stream;
        protected boolean input_stream;
    
        Channel(Object file_stream, Object object_stream, boolean input_stream) {
            this.file_stream = file_stream;
            this.object_stream = object_stream;
            this.input_stream = input_stream;
        }
    }
    
    /*
     * Identifier for a simple transformation.
     */
    public static final String TRANSFORM_SIMPLE = "SimpleTransformation";
    
    /*
     * Directory where serialized data is stored.
     */
    private static final String FILE_PREFIX = "/tmp/";
    
    /*
     * Suffix (including extension) of files used to store serialized data.
     */
    private static final String FILE_SUFFIX = "_data.xml";
    
    /*
     * Stores open channels.
     */
    private static NSMutableDictionary channels = new NSMutableDictionary();
    
    /*
     * Serializes data to a file.
     *
     * @param source          object to serialize
     * @param identifier      file identifier for deserialization
     *                        (name of the file without its path or extension)
     *
     * @return <code>true</code> when the process succeeds.
     */
    public static boolean serializeObject(Object source, String identifier) {
        String filename = FILE_PREFIX + identifier + FILE_SUFFIX;
        
        boolean success = transformObject(source, filename, null);
        
        return success;
    }
    
    /*
     * Deserializes data from a file.
     *
     * @param identifier      file identifier
     *                        (name of the file without the extension)
     *
     * @return deserialized object.
     */
    public static Object deserializeObject(String identifier) {
        String filename = FILE_PREFIX + identifier + FILE_SUFFIX;
        Object object = null;
    
        try {
            // Create a stream from the input file.
            NSXMLInputStream stream = (NSXMLInputStream)openStream(filename, true, null);
            
            // Deserialize data from input stream.
            object = stream.readObject();
            
            // Close stream
            closeStream(filename);
        }
        
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        return object;
    }
    
    /*
     * Serializes objects and data to a stream, which can also be
     * transformed. The product of the process is written to a file.
     *
     * @param source          object to serialize or transform
     * @param filename        filename of the target document,
     *                        including path and extension
     * @param transformation  type of transformation to perform;
     *                        indicates which transformation script to use.
     *                        When <code>null</code>, no transformation
     *                        is to be performed, only serialization.
     *
     * @return <code>true</code> when the process succeeds.
     */    
    public static boolean transformObject(Object source, String filename, String transformation) {
        boolean success = false;
    
        try {
            // Create a stream to the output file.
            NSXMLOutputStream stream = (NSXMLOutputStream)openStream(filename, false, transformation);
    
            // Serialize data to XML output stream.
            stream.writeObject(source);
    
            stream.flush();
            closeStream(filename);
            
            success = true;
        }
    
        catch (IOException e) {
            e.printStackTrace();
        }
    
        return success;
    }
    
    /*
     * Opens an output stream.
     *
     * @param filename         fully qualified filename of the target
     *                         or source file; identifies the channel to open.
     * @param transformation   type of transformation to perform;
     *                         indicates which transformation script to use.
     *                         When <code>null</code>, no transformation
     *                         is to be performed, only serialization.
     */
    public static NSXMLOutputStream openOutputStream(String filename, String transformation) throws IOException {
        return (NSXMLOutputStream)openStream(filename, false, transformation);
    }
    
    /*
     * Opens an input stream.
     *
     * @param filename   fully qualified filename of the target
     *                   or source file; identifies the channel to open.
     */
    public static NSXMLInputStream openInputStream(String filename) throws IOException {
        return (NSXMLInputStream)openStream(filename, true, null);
    }
    
    /*
     * Opens a file stream to or from a file and a corresponding
     * output or input object stream.
     * Adds the pair of streams to an internal dictionary for use by
     * the <code>closeStream</code> method.
     *
     * @param filename	       fully qualified filename of the
     *                         target or source file; identifies
     *                         the channel to open
     * @param input_stream     indicates whether the stream returned
     *                         is an input stream or an output stream:
     *                         <code>true</code> for an input stream and
     *			       <code>false</code> for an output stream.
     * @param transformation   type of transformation to perform;
     *                         indicates which transformation script to use.
     *                         When <code>null</code> no transformation
     *                         is to be performed, only serialization.
     *
     * @return object stream, <code>null</code> when the stream
     *         could not be created.
     */
    private static Object openStream(String filename, boolean input_stream, String transformation) throws IOException {
        BufferedOutputStream file_output_stream = null;
        BufferedInputStream file_input_stream = null;
        Channel channel;
        Object xml_stream = null;
    
        if (input_stream) {
            // Create an input stream from the file.
            file_input_stream = new BufferedInputStream(new FileInputStream(filename));
    
            // Create object input stream.
            xml_stream = new NSXMLInputStream(file_input_stream);
            
            channel = new Channel(file_input_stream, xml_stream, input_stream);
        } else {
            // Create an output stream to the file.
            file_output_stream = new BufferedOutputStream(new FileOutputStream(filename));
    
            // Create object output stream.
            if (transformation != null) {
                xml_stream = initializeTransformer(file_output_stream, transformation);
            } else {
                xml_stream = new NSXMLOutputStream(file_output_stream);
            }
    
            // Set the format of the output document (XML).
            NSXMLOutputFormat format = new NSXMLOutputFormat(true);
            ((NSXMLOutputStream)xml_stream).setOutputFormat(format);
            
            channel = new Channel(file_output_stream, xml_stream, input_stream);
        }
        channels.setObjectForKey(channel, filename);
        
        return xml_stream;
    }
    
    /*
     * Closes an object stream and its corresponding file stream.
     *
     * @param filename   fully qualified filename of the
     *                   target or source file; identifies
     *                   the channel to close
     */
    public static void closeStream(String filename) throws IOException {
        Channel channel = (Channel)channels.objectForKey(filename);
        
        if (channel.input_stream) {
            ((NSXMLInputStream)channel.object_stream).close();
            ((BufferedInputStream)channel.file_stream).close();
        } else {
            ((NSXMLOutputStream)channel.object_stream).close();
            ((BufferedOutputStream)channel.file_stream).close();
        }
        
        channels.removeObjectForKey(filename);
    }
    
    /*
     * Computes the URI of a transformation file.
     *
     * @param transformation   type of transformation (does not
     *                         include the .xsl extension);
     *                         for example, "SimpleTransformation"
     *
     * @return relative path to the transformation file.
     */
    private static String transformationURI(String transformation) {
        WOApplication application = WOApplication.application();
        WOResourceManager resource_manager = application.resourceManager();
        String transformationURI = resource_manager.pathForResourceNamed("SimpleTransformation" + ".xsl", null, null);

        return transformationURI;
    }
    
    /*
     * Initializes the transformer.
     *
     * @param file_stream       target file stream
     * @param transformation	type of transformation to perform;
     *                          indicates which transformation script to use
     *
     * @throws IOException when there's a problem initializing
     *         the transformer.
     */
    private static NSXMLOutputStream initializeTransformer(BufferedOutputStream file_stream, String transformation) throws IOException {
        NSXMLOutputStream xml_stream = new NSXMLOutputStream(file_stream, new File(transformationURI(transformation)));
        Transformer transformer = ((NSXMLOutputStream)xml_stream).transformer();
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        
        return xml_stream;
    }
}
