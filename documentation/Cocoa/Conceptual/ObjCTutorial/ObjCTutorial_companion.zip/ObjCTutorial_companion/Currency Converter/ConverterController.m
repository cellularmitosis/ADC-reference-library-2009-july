#import "ConverterController.h"
#import "Converter.h"

@implementation ConverterController
- (IBAction)convert:(id )sender {
	float amount;
	converter = [[Converter alloc]init];
	[converter setSourceCurrencyAmount:[dollarField floatValue]];
    [converter setRate:[rateField floatValue]];
	amount =   [converter convertCurrency];
	
	[amountField setFloatValue:amount];
	[rateField selectText:self];
}
@end
