This sample project builds a "Hello, world." application using AppleScript Studio.  The Hello Outline document describes in detail how to create this application, including all of the script source necessary.  

The script source you can use to build these examples is provided as text clippings in the Script_Text_Clippings folders.

The Hello Step 1 milestone project is a completed version of Step 1 from the outline, and the Hello Step 2 milestone project is a completed version of Step 2 from the outline.  

The Hello Step 2 milestone project also includes a test script for scripting the Hello application.  That script source is also provided as a text clipping.