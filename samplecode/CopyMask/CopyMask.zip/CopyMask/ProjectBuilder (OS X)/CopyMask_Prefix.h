//
// Prefix header for all source files of the 'CopyMask' target in the 'CopyMask' project.
//

#include <Carbon/Carbon.h>
