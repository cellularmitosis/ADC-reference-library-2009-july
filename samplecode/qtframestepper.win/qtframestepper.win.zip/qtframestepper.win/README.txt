README - QTFrameStepper

QTFrameStepper.c defines functions that you can use to step frame-by-frame through a QuickTime movie.
Indeed, it illustrates *two* different methods for doing this:

(1) using Movie Toolbox functions to advance (or retreat) to interesting times in the movie
(2) using movie controller actions to step forward or backward through a movie

See the top of the file QTFrameStepper.c for more detailed comments and instructions
on using this snippet.

Enjoy,
QuickTime Team

