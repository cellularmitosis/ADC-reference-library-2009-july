//
//  Person.java
//  Person
//


public class Person {
    private String firstName;
    private String lastName;
    private String gender;
    private String hairColor;
    
    public Person(String firstName, String lastName, String gender, String hairColor) {
        setFirstName(firstName);
        setLastName(lastName);
        setGender(gender);
        setHairColor(hairColor);
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String firstName() {
        return firstName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String lastName() {
        return lastName;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String gender() {
        return gender;
    }
    
    public void setHairColor(String hairColor) {
        this.hairColor = hairColor;
    }
    
    public String hairColor() {
        return hairColor;
    }
    
    public String toString() {
        return "{FirstName: " + firstName() + "},{LastName: " + lastName() + "},{Gender: " + gender() + "},{HairColor: " + hairColor() + "}";
    }
}