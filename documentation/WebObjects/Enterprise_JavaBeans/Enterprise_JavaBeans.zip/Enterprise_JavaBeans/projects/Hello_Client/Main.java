//
// Main.java: Class file for WO Component 'Main'
// Project Hello_Client
//

import my.ejb.Hello;

import java.rmi.RemoteException;

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoaccess.*;

public class Main extends WOComponent {
    public String greeting;

    public Main(WOContext context) {
        super(context);
        
        Session session = (Session)session();
        
        try {
            greeting = session.hello.message();
        }
        catch (RemoteException re) {
            re.printStackTrace();
        }
    }

}
