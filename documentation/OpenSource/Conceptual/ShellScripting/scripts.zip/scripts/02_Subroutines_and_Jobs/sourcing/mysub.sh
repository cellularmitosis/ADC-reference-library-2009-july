#!/bin/sh

mysub()
{
        local MYVAR
	MYVAR=3
	echo "SUBROUTINE: MYVAR IS $MYVAR";
}

