#!/bin/sh

mysub()
{
	echo "Arg 1: $1"

}

mysub "This is an arg"


