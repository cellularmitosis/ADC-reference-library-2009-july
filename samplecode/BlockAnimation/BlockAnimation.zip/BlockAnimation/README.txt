This is an example which INCORRECTLY handles animation. It is designed
as a simple example which developers can use practice with our debugging
tools to identify and isolate a problem.

This example consists of two main parts:

    1) A JFrame with lots of JPanels inside

    2) Many JPanels which periodically change their background color and repaint
