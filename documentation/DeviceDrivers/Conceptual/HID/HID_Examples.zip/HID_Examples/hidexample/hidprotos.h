
void MyTestQueues(IOHIDDeviceInterface **hidDeviceInterface, cookie_struct_t cookies);
void MyTestHIDInterface(IOHIDDeviceInterface ** hidDeviceInterface, cookie_struct_t cookies);
void MyFindHIDDevices(mach_port_t masterPort, io_iterator_t *hidObjectIterator);
void MyTestHIDDevices(io_iterator_t hidObjectIterator);


