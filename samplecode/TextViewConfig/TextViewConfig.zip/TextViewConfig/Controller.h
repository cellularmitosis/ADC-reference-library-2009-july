/*
        Controller.h
        TextViewConfig

        Author: DD
*/

#import <AppKit/AppKit.h>

@interface Controller : NSObject {
    IBOutlet NSTextView *singleTextView;
    IBOutlet NSView *customView;
}

@end
