//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SndEqualizer.rc
//
#define kAboutMenuItem                  1
#define IDS_APPNAME                     1
#define IDS_DESCRIPTION                 2
#define WINDOWMENU                      3
#define IDS_FILTERSTRING                3
#define IDI_APPICON                     101
#define IDI_CHILDICON                   102
#define IDD_ABOUT                       103
#define kMenuBarResID                   128
#define kAppleMenuResID                 128
#define kFileMenuResID                  129
#define kEditMenuResID                  130
#define kTestMenuResID                  131
#define IDS_WINDOWMENU                  1300
#define IDM_WINDOWTILE                  1301
#define IDM_WINDOWCASCADE               1302
#define IDM_WINDOWCLOSEALL              1303
#define IDM_WINDOWICONS                 1304
#define IDM_WINDOWCHILD                 1310
#define IDS_HELPMENU                    1400
#define IDM_ABOUT                       1401
#define IDS_SAVEONCLOSE                 2000
#define IDS_SAVEONQUIT                  2001
#define IDS_FILEMENU                    33024
#define IDM_FILENEW                     33025
#define IDM_FILEOPEN                    33026
#define IDM_FILECLOSE                   33027
#define IDM_FILESAVE                    33028
#define IDM_FILESAVEAS                  33029
#define IDM_EXIT                        33031
#define IDS_EDITMENU                    33280
#define IDM_EDITUNDO                    33281
#define IDM_EDITCUT                     33283
#define IDM_EDITCOPY                    33284
#define IDM_EDITPASTE                   33285
#define IDM_EDITCLEAR                   33286
#define IDM_EDITSELECTALL               33288
#define IDM_EDITSELECTNONE              33289
#define IDS_TESTMENU                    33536
#define IDM_SHOWHIDE_EQ                 33537
#define IDM_OPEN_SND_RESOURCE           33539
#define IDM_PLAY_SND_RESOURCE           33540
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
