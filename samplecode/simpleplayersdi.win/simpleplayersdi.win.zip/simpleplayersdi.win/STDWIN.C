/*
	File:		stdwin.c

	Written by: Keith Gurganus

  	Copyright:	� 1997 by Apple Computer, Inc., all rights reserved.
*/
#include "stdwin.h"

