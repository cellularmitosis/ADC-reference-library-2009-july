#!/bin/sh
printf "What is your name?  -> "
read NAME Age
echo "Hello, $NAME.  Nice to meet you.  You are $Age years old.  Man, that's young."
