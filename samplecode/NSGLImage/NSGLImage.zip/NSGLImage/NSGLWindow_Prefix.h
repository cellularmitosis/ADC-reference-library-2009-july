//
// Prefix header for all source files of the 'Cocoa OpenGL' target in the 'Cocoa OpenGL' project
//

#ifdef __OBJC__
    #import <Cocoa/Cocoa.h>
#endif