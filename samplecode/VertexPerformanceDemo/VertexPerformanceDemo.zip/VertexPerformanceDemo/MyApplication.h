#import <Cocoa/Cocoa.h>

@interface MyApplication : NSApplication
{
}
@end
