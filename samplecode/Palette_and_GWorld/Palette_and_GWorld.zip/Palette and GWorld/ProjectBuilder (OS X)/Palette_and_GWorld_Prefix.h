//
// Prefix header for all source files of the 'Palette and GWorld' target in the 'Palette and GWorld' project.
//

#include <Carbon/Carbon.h>
