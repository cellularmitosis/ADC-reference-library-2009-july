//
//  main.m
//  CapabilitiesSample
//
//  Created by Scott Kuechle on Tue Jun 04 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
