//
// �FILENAME�: Class file for Direct to Web Serivces Operation '�FILEBASENAME�'
// Project �PROJECTNAME�
//
// Created by �USERNAME� on �DATE�
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoaccess.*;
import com.webobjects.directtoweb.*;
import com.webobjects.webservices.generation.*;

public class �FILEBASENAME� extends WOOperation {

    public �FILEBASENAME�(WOContext context) {
        super(context);
    }

    public Object invoke() {
        // insert custom logic here
        return super.invoke();
    }
    
}
