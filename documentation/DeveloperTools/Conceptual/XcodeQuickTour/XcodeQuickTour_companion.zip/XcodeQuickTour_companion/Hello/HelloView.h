//
//  HelloView.h
//  Hello
//
//  Copyright 2008, Apple Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface HelloView : NSView {

}

@end
