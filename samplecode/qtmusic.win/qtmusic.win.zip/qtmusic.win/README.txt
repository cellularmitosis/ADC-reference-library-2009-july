README - QTMusic

QTMusic is a sample application that demonstrates ways of using the
QuickTime Music Architecture to play notes and tunes. It is based on 
sample code written by David Van Brink and explained in develop 
issue 23.  So far, the only changes I've made are to bring the 
source code into line with the latest header files and to port the 
code to Windows platforms. I've also added the ability to use custom
instruments to play tunes and in movies.

QTMusic can be compiled and run under the MacOS and under Windows. 
The main QTMA code is found in the file QTMusic.c. The remaining files 
in this folder are part of the general Mac and Windows support code.

Enjoy,
QuickTime Team

