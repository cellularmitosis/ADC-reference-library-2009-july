README - SimpleEditSDI

SimpleEditSDI is a sample application that demonstrates how to display and edit
QuickTime movies using the SDI (single document interface).

Enjoy,
QuickTime Team

