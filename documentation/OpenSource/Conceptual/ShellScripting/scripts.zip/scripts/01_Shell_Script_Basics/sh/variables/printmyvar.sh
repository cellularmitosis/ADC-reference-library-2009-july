#!/bin/sh

echo $MYVAR
