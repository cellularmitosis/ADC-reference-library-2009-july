//
// Application.java
// Project Security_Client
//
// Created by ernest on Tue Oct 29 2002
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;

public class Application extends WOApplication {
    
    public static void main(String argv[]) {
        WOApplication.main(argv, Application.class);
    }

    public Application() {
        super();
        System.out.println("Welcome to " + this.name() + "!");
        
        // Initialize security delegate Web services.
        SecurityDelegate delegate = new SecurityDelegate();
        
        // Set the security delegate for Web services.
        WOWebServiceRegistrar.setSecurityDelegate(delegate);
        
        // Create a Security client and invoke it's test method.
        SecurityClient securityClient = new SecurityClient();
        
        // Invoke SecurityClient.test().
        System.out.println();
        securityClient.test();
        System.out.println();
    }
}
