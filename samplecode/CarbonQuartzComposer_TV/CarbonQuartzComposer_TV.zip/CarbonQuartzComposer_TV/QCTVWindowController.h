/* QCTVWindowController */

#import <Cocoa/Cocoa.h>

@interface QCTVWindowController : NSWindowController
{
}
@end
