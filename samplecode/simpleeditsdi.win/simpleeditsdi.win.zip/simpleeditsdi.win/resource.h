//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SimpleEditSDI.rc
//
#define IDR_GENERIC                     128
#define IDR_SIMPLEMDI                   128
#define IDR_ACCELSIMPLEMDI              128
#define IDR_ACCELSIMPLESDI              128
#define IDR_SIMPLESDI                   128
#define IDR_SMALL                       129
#define IDR_WIN95                       131
#define IDD_ABOUTBOX                    132
#define IDI_BIG                         139
#define IDM_CLEAR                       40004
#define IDM_SELECTALL                   40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
