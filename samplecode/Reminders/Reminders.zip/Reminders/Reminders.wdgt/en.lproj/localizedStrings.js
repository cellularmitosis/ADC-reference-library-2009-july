var localizedStrings = new Object;

localizedStrings['preferredCalendars'] = 'preferredCalendars';
