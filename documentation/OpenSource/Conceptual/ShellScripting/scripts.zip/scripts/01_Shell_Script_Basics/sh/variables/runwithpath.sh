#!/bin/sh
GLOBAL_PATH="$PATH"
PATH=/usr/local/bin

PATH="$GLOBAL_PATH" /bin/ls
