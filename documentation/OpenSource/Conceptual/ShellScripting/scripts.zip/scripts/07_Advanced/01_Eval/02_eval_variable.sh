#!/bin/sh

VARIABLE="X"
eval $VARIABLE=3
echo $X
