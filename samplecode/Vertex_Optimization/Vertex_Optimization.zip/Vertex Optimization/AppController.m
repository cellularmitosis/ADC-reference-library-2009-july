#import "AppController.h"

@implementation AppController

- (void)UpdateDrawing
{
    [mainGLView setNeedsDisplay:true];
}

@end
