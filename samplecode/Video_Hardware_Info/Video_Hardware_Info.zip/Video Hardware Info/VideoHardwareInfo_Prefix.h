//
// Prefix header for all source files of the 'VideoHardwareInfo' target in the 'VideoHardwareInfo' project
//

#ifdef __OBJC__
    #import <Cocoa/Cocoa.h>
#endif
