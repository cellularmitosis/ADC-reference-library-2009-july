
void free_message(Qmessage *message);

/* Returns 1 if messsage handled, 0 if socket closed, -1 on error */
int handle_message(comm_channel *channel)
{
	Qmessage msg;

	memset(&msg, 0, sizeof(msg));

	/* Read the message type byte */
	if (read(channel->in_fd, &msg.message_type, 1) != 1) {
		/* Socket closed. */
		fprintf(stderr, "Connection closed.\n");
		exit (0);
	}

	/* Read the message id */
	if (read(channel->in_fd, &msg.message_id, sizeof(msg.message_id)) != sizeof(msg.message_id)) {
		fprintf(stderr, "Message id truncated.\n");
		goto error_exit;
	}

	/* Read the message length */
	if (read(channel->in_fd, &msg.message_length, sizeof(msg.message_length)) != sizeof(msg.message_length)) {
		fprintf(stderr, "Message length truncated.\n");
		goto error_exit;
	}

	/* Allocate a buffer for the message and read it. */
	msg.message_contents = malloc(msg.message_length);
	if (!msg.message_contents) {
		fprintf(stderr, "Call to malloc failed\n");
		goto error_exit;
	}
	if (msg.message_type == _private_RESPONSE) {
		if (read(channel->in_fd, &msg.response_id, sizeof(msg.response_id)) != sizeof(msg.response_id)) {
			fprintf(stderr, "Message reply ID truncated.\n");
			goto error_exit;
		}
	}

	if (msg.message_length) {
		if (read(channel->in_fd, msg.message_contents, msg.message_length) != msg.message_length) {
			fprintf(stderr, "Got too few bytes before EOF reading data.\n");
			goto error_exit;
		}
	}

	switch(msg.message_type) {
		case msg_type_string:
			// fprintf(stderr, "Received string %s\n", buf);
			handle_string(channel, &msg);
			break;
		case _private_RESPONSE:
			handle_response(channel, &msg);
			break;
		default:
			fprintf(stderr, "UNKNOWN MESSAGE TYPE %d\n", msg.message_type);
			exit(-1);
	}

	return 1;
    error_exit:
	fprintf(stderr, "Data truncation error.\n");
	perror(APPNAME);
	return -1;
}

void msg_listen(comm_channel *channel, int exit_on_close)
{
	fd_set fdlist;
	struct timeval tv;
	char junk;

	/* Set up the fd_set so that calls to select() will watch
	   for data on standard input (or whatever is passed in
	   via in_fd).
	 */
	FD_ZERO(&fdlist);
	FD_SET(channel->in_fd, &fdlist);

	tv.tv_sec = 0;
	tv.tv_usec = 1000; // 1 ms.
	// tv.tv_sec = 1;
	// tv.tv_usec = 0;

	/* Wait for data. */
    restart:
	while (select(channel->in_fd+1, &fdlist, NULL, NULL, &tv) != -1) {
		int message_handled;
		/* Since this is only watching one file descriptor,
		   it doesn't need a for loop here.  Normally,
		   this code would iterate through all of the
		   descriptors (or lazily iterate from 0 to
		   FD_SETSIZE) and check to see if each descriptor
		   is set using FD_ISSET.
		 */
		// fprintf(stderr, "DEBUG: LOOP\n");
		if (FD_ISSET(channel->in_fd, &fdlist)) {
			fprintf(stderr, "Handling message\n");
			message_handled = handle_message(channel);
			if (!message_handled && exit_on_close) return;
		}

		/* Reset the fd_set.  Note that select() will zero
		   the set except for descriptors that have data
		   pending, so we have to set the descriptor again
		   or select will fail after the first timeout.
		 */
		FD_SET(channel->in_fd, &fdlist);

		/* Some UNIX/Linux implementations may adjust tv to be the
		   remaining sleep time. */
		tv.tv_sec = 0;
		tv.tv_usec = 1000; // 1 ms.
		// tv.tv_sec = 1;
		// tv.tv_usec = 0;
	}
	if (errno == EINTR) {
		goto restart;
	}
}

Qmessage *msg_send(comm_channel *channel, uint8_t type, void *data, uint64_t datalen, msg_flags flags)
{
	return msg_send_priv(channel, type, data, datalen, flags, 0);
}

Qmessage *msg_reply(comm_channel *channel, Qmessage *message, msg_flags flags)
{
	return msg_send_priv(channel, _private_RESPONSE, message->response_contents, message->response_length, flags, message->message_id);
}

Qmessage *msg_send_priv(comm_channel *channel, uint8_t type_parm, void *data, uint64_t datalen_parm, msg_flags flags, uint64_t replyid_parm)
{
    uint8_t typeid = type_parm;
    uint64_t datalen = datalen_parm;
    uint64_t msgid;
    uint64_t replyid = replyid_parm;
    Qmessage *msg = malloc(sizeof(*msg));

    if (!msg) return NULL;

    memset(msg, 0, sizeof(msg));
    msg->message_type = typeid;
    msg->message_length = datalen;
    msg->message_contents = data;

    msgid = (uint64_t)(uintptr_t)msg;

    if (!(flags & MSG_SYNC)) {
	fprintf(stderr, "Async operation not implemented\n");
	return NULL;
    }
    /* Write the type byte. */
    if (write(channel->out_fd, &typeid, sizeof(typeid)) != sizeof(typeid)) goto error_exit;

    /* Write the message ID. */
    if (write(channel->out_fd, &msgid, sizeof(msgid)) != sizeof(msgid)) goto error_exit;

    /* Write the length. */
    if (write(channel->out_fd, &datalen, sizeof(datalen)) != sizeof(datalen)) goto error_exit;

    /* For response data, the next thing sent is the original message ID. */
    if (typeid == _private_RESPONSE) {
	if (write(channel->out_fd, &replyid, sizeof(replyid)) != sizeof(replyid)) goto error_exit;
    }
    /* Now write the data. */
    if (write(channel->out_fd, data, datalen) != datalen) goto error_exit;

    if (flags & MSG_EXPECT_RESPONSE) {
	if (pending) {
		msg->next = pending;
		pending->prev = msg;
		pending = msg;
	} else {
		pending = msg;
	}
    }

    return msg;

    error_exit:
	fprintf(stderr, "Message write failed.\n");
	perror(APPNAME);
	free(msg);
	return NULL;

}

void process_response(comm_channel *channel, Qmessage *message)
{
	// fprintf(stderr, "Got response: %s\n", message->message_contents);

	Qmessage *ptr = pending;

	while (ptr && ((uint64_t)(uintptr_t)ptr != message->response_id)) {
		ptr = ptr->next;
	}
	if (!ptr) {
		fprintf(stderr, "Received message with unknown response ID 0x%x.  Dropping.\n", message->response_id);
		return;
	}

	/* Dequeue the pending message. */
	if (pending == ptr) {
		pending = ptr->next;
		pending->prev = NULL;
	} else {
		ptr->prev->next = ptr->next;
		if (ptr->next) ptr->next->prev = ptr->prev;
	}

	ptr->response_length = message->message_length;
	ptr->response_contents = message->message_contents;
	message->message_contents = 0;
	message->message_length = 0;
	free_message(message);

	/* Handle it. */
	handle_response(channel, ptr);
}

void free_message(Qmessage *message)
{
	if (message->message_contents) free(message->message_contents);
	if (message->response_contents) free(message->response_contents);
	message->next = (void *)0xDEADBEEFUL;
	message->prev = (void *)0xFEEDBABEUL;
	message->message_type = _private_INVALID;
	free(message);
}

