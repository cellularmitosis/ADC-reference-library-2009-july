//
// Prefix header for all source files of the 'Monochrome Image' target in the 'Monochrome Image' project
//

#ifdef __OBJC__
    #import <Cocoa/Cocoa.h>
#endif
