#!/bin/sh
# Save as sourcetest2.sh
MYVAR=4
