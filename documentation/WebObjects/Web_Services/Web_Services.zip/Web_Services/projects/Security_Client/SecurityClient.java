//
//  SecurityClient.java
//  Security_Client
//

import com.webobjects.foundation.*;
import com.webobjects.webservices.client.WOWebServiceClient;

import java.net.MalformedURLException;
import java.net.URL;

public class SecurityClient {

    /**
     * Object through which the Web service's operations are invoked.
     */
    private WOWebServiceClient _serviceClient = null;
    
    /**
     * Address for the Web service's WSDL document.
     */
    private String _service_address = "http://localhost:4230/cgi-bin/WebObjects/Security.woa/ws/SecureService?wsdl";

    /**
     * Constructor. Invokes the test method.
     */
    public SecurityClient() {
        super();
    }

    /**
     * Invokes the test method of the SecureService Web service.
     */
    public void test() {
        System.out.println("<SecurityClient> test()");
        serviceClient().invoke(serviceName(), "test", null);
    }
    
    //public void activateSecurity() {
    //    serviceClient().invoke(serviceName(), "activateSecurity", null);
    //}
    
    //public void deactivateSecurity() {
    //    serviceClient().invoke(serviceName(), "deactivateSecurity", null);
    //}

    /**
     * Obtains the Web service name.
     * Normally one WSDL file describes one Web service,
     * but it could describe one or more services.
     * @return Web service name.
     */
    public String serviceName() {
        return (String)serviceClient().serviceNames().objectAtIndex(0);
    }
    
    /**
     * Obtains an agent through which service operations are invoked.
     * @return service agent.
     */
    private WOWebServiceClient serviceClient() {
        if (_serviceClient == null) {
            _serviceClient = clientFromAddress(_service_address);
        }
        return _serviceClient;
    }
    
    /**
     * Obtains a Web service-client object through which
     * service operations can be invoked.
     * @return Web service-client object.
     */
    private static WOWebServiceClient clientFromAddress(String address) {
        WOWebServiceClient service_client = null;

        // Create the Web service's URL.
        URL url;
        try {
            url = new URL(address);
        }
        catch (MalformedURLException e) {
            url = null;
        }

        // Get a service-client object.
        service_client = new WOWebServiceClient(url);

        return service_client;
    }
}
