Find accounts by name.applescript

This AppleScript for use with iChat demonstrates finding accounts through scripting. 

When run, it prompts you for a string, and then returns all accounts whose full names match that string.