//
// Main.java: Class file for WO Component 'Main'
//

import java.lang.*;

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoaccess.*;

public class Main extends WOComponent {

    // User input: operation to invoke. Linked to pop-up menu.
    protected String operation;

    // User input: operands. Linked to text fields.
    protected String first_number_as_string;
    protected String second_number_as_string;
    
    // Operation output: result of operation. Linked to disabled text field.
    protected String operation_result_as_string;
    
    // Object used to invoke the Calculator Web service's operations.
    protected CalculatorClient calculator_client;
    
    public Main(WOContext context) {
        super(context);

        // Create the Calculator service client.
        calculator_client = new CalculatorClient();
    }

    // Gets values entered in text fields, invokes the operation,
    // and puts the result in the output text field.
    public WOComponent calculate() {
        try {
            // Create argument values.
            double argument1 = Double.parseDouble(first_number_as_string);
            double argument2 = Double.parseDouble(second_number_as_string);
            
            // Create argument list.
            Object[] arguments = { new Double(argument1), new Double(argument2) };

            // Invoke the operation.
            Double result = calculator_client.invoke(operation, arguments);
            double result_value = result.doubleValue();

            first_number_as_string = Double.toString(argument1);
            second_number_as_string = Double.toString(argument2);
            operation_result_as_string = Double.toString(result_value);
        }
        
        catch (NumberFormatException nfe) {
            nfe.printStackTrace();
        }

        return null;
    }
}
