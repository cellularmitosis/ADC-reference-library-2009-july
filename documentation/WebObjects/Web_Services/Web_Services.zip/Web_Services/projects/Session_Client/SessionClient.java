//
//  SessionClient.java
//  Session_Client
//

import java.net.*;

import com.webobjects.appserver.*;
import com.webobjects.foundation.*;
import com.webobjects.webservices.client.*;

/**
 * Used to consume the LogIn and AccessData Web services.
 */
public class SessionClient extends Object {
    
    private WOWebServiceClient _logInClient = null;
    private WOWebServiceClient _accessDataClient = null;
    
    private final String LogInServiceAddress = "http://localhost:4220/cgi-bin/WebObjects/Session.woa/ws/LogIn?wsdl";
    private final String AccessDataServiceAddress = "http://localhost:4220/cgi-bin/WebObjects/Session.woa/ws/AccessData?wsdl";

    private final String LogInService = "LogIn";
    private final String AccessDataService = "AccessData";

    
    public SessionClient() {
        super();
    }

    /**
     * Invokes the setUserInfo operation of the LogIn Web service.
     */
    public void logIn(String name, String password) {
        Object[] arguments = { name, password };
        logInClient().invoke(LogInService, "setUserInfo", arguments);
    }
    
    /**
     * Invokes the userName operation of the AccessData Web service.
     * @return user name stored in shared session object.
     */
    public String userName() {
        Object[] arguments = {};
        Object result = accessDataClient().invoke(AccessDataService, "userName", arguments);
        return (String)result;
    }
    
    /**
     * Invokes the userPassword operation of the AccessData Web service.
     * @return user password stored in shared session object.
     */
    public String userPassword() {
        Object[] arguments = {};
        Object result = accessDataClient().invoke(AccessDataService, "userPassword", arguments);
        return (String)result;
    }

    /**
     * Obtains a Web service client through which LogIn operations are invoked.
     * @return a Web service client for LogIn.
     */
    protected WOWebServiceClient logInClient() {
        if (_logInClient == null) {
            _logInClient = clientFromAddress(LogInServiceAddress);
        }
        return _logInClient;
    }
    
    /**
     * Obtains a Web service client through which AccessData operations are invoked.
     * @return a Web service client for AccessData.
     */
    protected WOWebServiceClient accessDataClient() {
        if (_accessDataClient == null) {
            _accessDataClient = clientFromAddress(AccessDataServiceAddress);
        }
        return _accessDataClient;
    }

    /**
     * Obtains the session used by LogInService.
     * @return session information from LogInService.
     */
    public WOWebService.SessionInfo logInSessionInfo() {
        return logInClient().sessionInfoForServiceNamed(LogInService);
    }
    
    /**
     * Sets the session used by AccessDataService.
     */
    public void setAccessDataSessionInfo(WOWebService.SessionInfo sessionInfo) {
        accessDataClient().setSessionInfoForServiceNamed(sessionInfo, AccessDataService);
    }
    
    /**
     * Obtains a Web service client through which
     * service operations are invoked.
     * @return Web service client object.
     */
    private WOWebServiceClient clientFromAddress(String address) {
        WOWebServiceClient service_client = null;

        // Create the Web service's URL.
        URL url;
        try {
            url = new URL(address);
        }
        catch (MalformedURLException e) {
            url = null;
        }

        // Get a service-client object.
        service_client = new WOWebServiceClient(url);

        return service_client;
    }
}
