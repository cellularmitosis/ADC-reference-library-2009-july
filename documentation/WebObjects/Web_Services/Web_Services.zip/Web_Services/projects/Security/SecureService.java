//
//  SecureService.java
//  Security
//

import com.webobjects.appserver.WOWebServiceRegistrar;
import com.webobjects.foundation.*;

public class SecureService {

    //private Object _delegate = null;

    public SecureService() {
        super();
    }

    
    /**
     * Activates the security delegate.
     * @return <code>true</code>.
     */
    //private boolean activateSecurity() {
    //    System.out.println("SecureService: activateSecurity");
    //    if (_delegate == null) {
    //    }
    //    
    //    // Set the security delegate for Axis to use.
    //    System.out.println("  Setting security delegate through WOWebServiceRegistrar");
    //    WOWebServiceRegistrar.setSecurityDelegate(_delegate);
    //    
    //    return true;
    //}
    
    /**
     * Deactivates the security delegate.
     * @return <code>true</code>.
     */
    //private boolean deactivateSecurity() {
    //    System.out.println("SecureService: deactivateSecurity");
    //    WOWebServiceRegistrar.setSecurityDelegate(null);
    //    return true;
    //}

    public void test() {
        System.out.println("<SecureService> test()");
    }
}
