//
//  main.m
//  CalendarItems
//
//  Created by admin on 3/28/07.
//  Copyright (C) 2007 Apple Inc. All Rights Reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
