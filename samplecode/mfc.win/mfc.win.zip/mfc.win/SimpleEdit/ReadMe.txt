========================================================================
       QuickTime 2.5 : SimpleEdit MFC
========================================================================
A Microsoft MFC application that plays a movie with QuickTime and enables editing
