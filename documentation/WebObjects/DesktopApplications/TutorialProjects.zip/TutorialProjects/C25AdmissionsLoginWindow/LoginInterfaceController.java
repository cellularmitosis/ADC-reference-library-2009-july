//
//  LoginInterfaceController.java
//  $ProjectName$
//
//  Created by $FullUserName$ on $The_Date$.
//  Copyright (c) 2001 $OrganizationName$. All rights reserved.
//

package admissions.client;

import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoapplication.*;
import com.webobjects.eodistribution.client.*;
import com.webobjects.eointerface.swing.*;
import javax.swing.*;
import businesslogic.client.*;

public class LoginInterfaceController extends EOInterfaceController {

    public EOTextField username;
    public JPasswordField password;
    private Person _user;

    public LoginInterfaceController() {
        super();
    }

    public LoginInterfaceController(EOEditingContext substitutionEditingContext) {
        super(substitutionEditingContext);
    }
    
    public void login() {
        if (this.clientSideRequestLogin()) {
            /* Allow user into application, usually by displaying another nib:
                MainMenuInterfaceController mainMenu = new MainMenuInterfaceController();
                EOFrameController.runControllerInNewFrame(mainMenu, null);
            */
        }
        else {
            EODialogs.runErrorDialog("Login failed", "Login failed. Please try again.");
        }
    }
    
    public void clear() {
        username.setText("");
        password.setText("");
    }
    
    public boolean clientSideRequestLogin() {
 	EOGlobalID person = (EOGlobalID)(_distributedObjectStore().
            invokeStatelessRemoteMethodWithKeyPath("session", "clientSideRequestLogin", 
            new Class[] {String.class, String.class},new Object[] {username.getText(), new String(password.getPassword())}));
 	if (person != null) {
            EOEditingContext ec = new EOEditingContext();
            _user = (Person)(ec.faultForGlobalID(person, ec));
            return true;
 	}
 	else
            return false;
    }
    
    private EODistributedObjectStore _distributedObjectStore() {
        EOObjectStore objectStore = EOEditingContext.defaultParentObjectStore();
        if ((objectStore == null) || (!(objectStore instanceof EODistributedObjectStore))) {
            throw new IllegalStateException("Default parent object store needs to be an              EODistributedObjectStore");
        }
        return (EODistributedObjectStore)objectStore;
    }
    
    
}
