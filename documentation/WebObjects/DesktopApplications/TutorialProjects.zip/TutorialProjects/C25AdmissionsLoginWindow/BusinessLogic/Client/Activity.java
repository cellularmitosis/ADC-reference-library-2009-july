// Activity.java
// Created on Tue Aug 27 17:15:19 US/Pacific 2002 by Apple EOModeler Version 5.2

package businesslogic.client;

import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;
import java.math.BigDecimal;
import java.util.*;

public class Activity extends EOGenericRecord {

    public Activity() {
        super();
    }

/*
    // If you implement the following constructor EOF will use it to
    // create your objects, otherwise it will use the default
    // constructor. For maximum performance, you should only
    // implement this constructor if you depend on the arguments.
    public Activity(EOEditingContext context, EOClassDescription classDesc, EOGlobalID gid) {
        super(context, classDesc, gid);
    }
*/


    public NSTimestamp since() {
        return (NSTimestamp)storedValueForKey("since");
    }

    public void setSince(NSTimestamp value) {
        takeStoredValueForKey(value, "since");
    }

    public String name() {
        return (String)storedValueForKey("name");
    }

    public void setName(String value) {
        takeStoredValueForKey(value, "name");
    }

    public String achievements() {
        return (String)storedValueForKey("achievements");
    }

    public void setAchievements(String value) {
        takeStoredValueForKey(value, "achievements");
    }
}
