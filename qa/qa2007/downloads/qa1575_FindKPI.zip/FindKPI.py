#! /usr/bin/python

import sys
import os
import subprocess   # requires Python 2.5
import plistlib

def addExportedSymbols(symDict, kextPath):
    infoPlist = plistlib.readPlist(os.path.join(kextPath, "Info.plist"))
    if infoPlist.has_key('CFBundleExecutable'):
        bundleID = infoPlist['CFBundleIdentifier']
        imagePath = os.path.join(kextPath, infoPlist['CFBundleExecutable'])
        symbols = subprocess.Popen(
            ["nm", "-j", imagePath], 
            stdout=subprocess.PIPE
        ).communicate()[0].split("\n")
        for sym in symbols:
            if sym != "":
                assert not symDict.has_key(sym)
                symDict[sym] = bundleID

def getSymbolsForExtensions():
    kextDir = "/System/Library/Extensions/System.kext/PlugIns"
    symDict = {}
    for kextName in os.listdir(kextDir):
        # Don't consider certain KEXTs.  Specifically exclude the 
        # Unsupported and MACFramework KEXTs.  Also, ignore any 
        # "6.0" KEXTs, which are present for compatibility only.
        if (   kextName not in ("Unsupported.kext", "MACFramework.kext")
           and not os.path.splitext(kextName)[0].endswith("6.0") ):
            addExportedSymbols(symDict, os.path.join(kextDir, kextName))
    return symDict

if len(sys.argv) < 2:
    print >> sys.stderr, "usage: %s name..." % os.path.basename(sys.argv[0])
    print >> sys.stderr, "    where name is either a C function name or a C++ class name"
    sys.exit(1)
else:
    symDict = getSymbolsForExtensions()
    for arg in sys.argv[1:]:
        sym = "_" + arg
        if sym in symDict:
            id = symDict[sym]
        else:
            sym = "__ZTV%d%s" % (len(arg), arg)
            if sym in symDict:
                id = symDict[sym]
            else:
                id = "*** not found ***"
        print "%s %s" % (arg, id)
