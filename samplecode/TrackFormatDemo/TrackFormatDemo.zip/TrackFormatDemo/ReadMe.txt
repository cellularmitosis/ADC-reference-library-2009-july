This sample illustrates how to get a human readable string for a track's format.

