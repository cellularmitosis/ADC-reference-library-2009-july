//
//  main.m
//  FancyAbout
//
//  Created by Mike Morton on Wed May 28 2003.
//  Copyright (c) 2003 Apple Computer, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
