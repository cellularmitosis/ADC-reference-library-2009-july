#!/bin/sh
eval X=3
echo $X
