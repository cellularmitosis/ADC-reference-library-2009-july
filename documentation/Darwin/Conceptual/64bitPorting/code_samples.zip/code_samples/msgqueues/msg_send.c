
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/errno.h>
#include "msgQ.h"
#include "protos.h"
#define APPNAME "msg_send"

comm_channel *startchild(char *path);

main()
{
    char *data = "This is an arbitrary piece of data";
    comm_channel *channel = startchild("./msg_recv");

    sleep(1);

    msg_send(channel, msg_type_string, data, strlen(data)+1, MSG_SYNC| MSG_EXPECT_RESPONSE);

    msg_listen(channel, 1);
    // handle_message(channel);

}

comm_channel *startchild(char *path)
{
	comm_channel *channel = malloc(sizeof(*channel));
	pid_t childpid;
	int in_descriptors[2];
	int out_descriptors[2];

	/* Create a pair of file descriptors to use for communication. */
	if (pipe(in_descriptors) == -1) {
		fprintf(stderr, "pipe creation failed.\n");
		goto error_exit;
	}
	if (pipe(out_descriptors) == -1) {
		fprintf(stderr, "pipe creation failed.\n");
		goto error_exit;
	}

	/* Create a new child process. */
	if ((childpid = fork()) == -1) {
		fprintf(stderr, "fork failed.\n");
		goto error_exit;
	}
	if (childpid) {
		/* Parent process */

		channel->in_fd = in_descriptors[0];
		close(in_descriptors[1]);
		channel->out_fd = out_descriptors[1];
		close(out_descriptors[0]);

		return channel;
	} else {
		/* Child process */

		if (dup2(in_descriptors[1], STDOUT_FILENO) == -1) {
			fprintf(stderr, "Call to dup2 failed.\n");
			goto error_exit;
		}
		close(in_descriptors[0]);
		if (dup2(out_descriptors[0], STDIN_FILENO) == -1) {
			fprintf(stderr, "Call to dup2 failed.\n");
			goto error_exit;
		}
		close(out_descriptors[1]);

		execl(path, path, NULL);

		/* If we get here, something went wrong. */
		fprintf(stderr, "Exec failed.\n");
		goto error_exit;
	}

	return channel;
	
    error_exit:

	free(channel);
	perror("msg_send");
	return NULL;
}


void handle_string(comm_channel *channel, Qmessage *message)
{
	return;
}

void handle_response(comm_channel *channel, Qmessage *message)
{
	fprintf(stderr, "Got response: %s\n", message->message_contents);
	exit (0);
}


#include "shared.c"

