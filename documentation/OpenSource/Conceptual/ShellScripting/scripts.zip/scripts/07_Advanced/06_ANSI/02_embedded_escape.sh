#!/bin/sh

echo "c" # Resets the screen.

