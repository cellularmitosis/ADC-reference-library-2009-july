#!/bin/sh

ESC=`printf "\e"`	# store an escape character
                        # into the variable ESC
echo "$ESC""c"		# Echo a terminal reset command.

