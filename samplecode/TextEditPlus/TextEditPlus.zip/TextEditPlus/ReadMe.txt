This sample project is based on the /Developer/Examples/AppKit/TextEdit and adds additional properties to the Document Properties inspector using AppleScript Studio.

The TextEditPlus Outline document describes in detail how to create this application, including all of the script and other source necessary.  The source is also provided as text clippings in the Text Clippings folder.

Each milestone project is a completed version of that step in the outline, e.g. the TextEditPlus Step 2 milestone project is a completed version of Step 2 from the outline.