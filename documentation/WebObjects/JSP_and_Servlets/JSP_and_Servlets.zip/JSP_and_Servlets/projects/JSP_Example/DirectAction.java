//
// DirectAction.java
// Project JSP_Example
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;

public class DirectAction extends WODirectAction {

    public DirectAction(WORequest aRequest) {
        super(aRequest);
    }

    public WOActionResults defaultAction() {
        return pageWithName("Main");
    }

    public WOActionResults loginAction() {
        FoodInquiry result = (FoodInquiry)pageWithName("FoodInquiry");
        
        // Get form values.
        String visitorName = request().stringFormValueForKey("VisitorName");
        String favoriteFood = request().stringFormValueForKey("FavoriteFood");
        
        // Set the component's instance variables.
        result.setVisitorName(visitorName);
        result.setFavoriteFood(favoriteFood);
        
        return result;
    }
}
