TuneBot.applescript
v1.0

This script demonstrates an AppleScript "Message Received" handler for iChat. It will take an incoming message and attempt to parse it into a command for iTunes.

To install:

1. Copy the file "TuneBot.applescript" into ~/Library/Scripts/iChat.

2. Set the handler up in iChat by opening Preferences and going to Alerts.

3. For the event "Message Received," check the box for "Run AppleScript" and select "TuneBot" from the dropdown.

4. Repeat for the "Text Invitation" event.
