#ifndef _VECTOR_HPP_
#define _VECTOR_HPP_

#ifdef __cplusplus

#include "Vector2.hpp"
#include "Vector3.hpp"

#endif

#endif
