//
//  main.m
//  MP3 Player
//
//  Created by Matthew Formica on Thu Feb 07 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
