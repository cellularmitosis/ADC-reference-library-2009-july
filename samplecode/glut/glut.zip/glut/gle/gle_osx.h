// These are normally defined on the compiler command line.
// They are in a file because PB does not support per-file
// -D switches.

#define OPENGL_10 1
#define AUTO_TEXTURE 1
#define __GUTIL_DOUBLE 1
