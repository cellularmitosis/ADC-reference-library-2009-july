//
//  ConverterController.h
//  Currency Converter
//
//  Created by Generic on 7/9/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Converter.h"

@interface ConverterController : NSObject {
    IBOutlet NSTextField *amountField;
    IBOutlet NSTextField *dollarField;
    IBOutlet NSTextField *rateField;
	Converter *converter;
}

- (IBAction)convert:(id )sender;
@end

