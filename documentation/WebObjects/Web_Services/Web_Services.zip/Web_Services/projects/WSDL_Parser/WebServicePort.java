//
//  WebServicePort.java
//  Project WSDL_Parser
//

import java.net.URL;
import java.net.MalformedURLException;
import java.util.Enumeration;
import javax.xml.namespace.QName;

import org.apache.axis.encoding.DeserializerFactory;
import org.apache.axis.encoding.SerializerFactory;
import org.apache.axis.encoding.ser.ArraySerializerFactory;
import org.apache.axis.encoding.ser.ArrayDeserializerFactory;
import org.apache.axis.encoding.ser.BeanDeserializerFactory;
import org.apache.axis.encoding.ser.BeanSerializerFactory;

import com.webobjects.foundation.*;
import com.webobjects.webservices.client.*;

/**
 * This class shows how to use WOWebServiceClient, WOWebServiceOperation,
 * and WOWebServiceParameter to implement a simple Web service port.
 */
public class WebServicePort extends Object {
    /**
     * Stores the WOWebServiceClient used to interact with the Web service.
     */
    private WOWebServiceClient _port = null;

    /**
     * Stores the URL to the WSDL document this WebServicePort was initialized with.
     */
    private String _address = null;

    /**
     * Stores the name of the Web service to use when invoke(String, Object[]) is used.
     * @see #initPortFromURL(URL)
     */
    private String _defaultServiceName = null;
    
    /**
     * Creates a WebServicePort from a WSDL document found at a particular URL.
     * @param address   string containting the WSDL document's URL;
     */
    public WebServicePort(String address) {
        initPortFromAddress(address);
    }

    /**
     * Creates a WebServicePort from a WSDL document found at a particular URL.
     * @param url   URL for the WSDL document;
     */
    public WebServicePort(URL url) {
        initPortFromURL(url);
    }

    /**
     * Creates an uninitialized WebServicePort.
     */
    public WebServicePort() {
        super();
    }

    /**
     * Invokes a Web service's operations.
     * @param service        service to use
     * @param operation      operation to invoke
     * @param arguments      argument list
     * @return               value returned by the operation.
     */
    public Object invoke(String service, String operation, Object[] arguments) {
        // API: WOWebServiceClient.invoke(String, String, Object[])
        Object result = port().invoke(service, operation, arguments);

        return result;
    }

    /**
     * Invokes the default Web service's operations.
     * @param operation      operation to invoke;
     * @param arguments      argument list;
     * @return               value returned by the operation.
     */
    public Object invoke(String operation, Object[] arguments) {
        return invoke(defaultServiceName(), operation, arguments);
    }

    /**
     * Returns the services defined by the WSDL document.
     * @return array os WOWebServiceServices.
     */
    public NSArray services() {
        // API: WOWebServiceClient.servicesDictionary()
        NSArray services = port().servicesDictionary().allValues();
        
        return services;
    }

    /**
     * Returns the names of the services defined the WSDL document.
     * @return array of Strings with Web service names.
     */
    public NSArray serviceNames() {
        // API: WOWebServiceClient.serviceNames()
        NSArray service_names = port().serviceNames();
        
        return service_names;
    }

    /**
     * Returns the operations provided by a particular Web service.
     * @param serviceName   name of the Web service;
     * @return array of WOWebServiceOperations.
     */
    public NSArray operationsForService(String serviceName) {
        // API: WOWebServiceClient.operationsDictionaryForService(String)
        NSArray operations = (_port.operationsDictionaryForService(serviceName)).allValues();

        return operations;
    }

    /**
     * Prints the Web service's information to the console."
     */
    public void showServiceInfo() {
        System.out.println();
        System.out.println("********************************");
        System.out.println("Web services located at " + address());
        System.out.println();
        NSArray services = port().servicesDictionary().allValues();
        Enumeration services_enumerator = services.objectEnumerator();
        while (services_enumerator.hasMoreElements()) {
            WOWebService service = (WOWebService)services_enumerator.nextElement();
            System.out.println(service.name() + "'s operations:");
            System.out.println();

            // API: WOWebServiceClient.operationsDictionaryForService(String)
            NSArray operations = port().operationsDictionaryForService(service.name()).allValues();

            Enumeration operations_enumerator = operations.objectEnumerator();
            while (operations_enumerator.hasMoreElements()) {
                WOClientOperation operation = (WOClientOperation)operations_enumerator.nextElement();
                System.out.println("   Operation " + operation.name() + ", " + operation.style());

                // API: WOClientOperation.parameters()
                NSArray parameters = operation.parameters();
                Enumeration parameters_enumerator = parameters.objectEnumerator();
                if (parameters_enumerator.hasMoreElements()) {
                    System.out.println("       Parameters:");
                    while (parameters_enumerator.hasMoreElements()) {
                        WOClientParameter parameter = (WOClientParameter)parameters_enumerator.nextElement();

                        // API: WOClientParameter.name(), typeQName(), parameterMode()
                        System.out.println("           " + parameter.name() + ", " + parameter.typeQName() + ", " + parameter.parameterMode());
                    }
                }
                NSArray return_types = operation.returnTypes();
                Enumeration return_types_enumerator = return_types.objectEnumerator();
                if (return_types_enumerator.hasMoreElements()) {
                    System.out.println("       Return values:");
                    while (return_types_enumerator.hasMoreElements()) {
                        WOClientParameter return_type = (WOClientParameter)return_types_enumerator.nextElement();
                        System.out.println("           " + return_type.name() + ", " + return_type.typeQName());
                    }
                }
                System.out.println();
            }
            System.out.println();
        }
        System.out.println("********************************");
    }

    /**
     * Returns the URL used to initialize this WebServicePort.
     * @return the URL used to initialize this WebServicePort.
     */
    public String address () {
        return _address;
    }

    public WOWebServiceClient port() {
        return _port;
    }

    /**
     * Returns the name of the Web service that the invoke(String, Object[]) method uses.
     * For WSDL documents that describe one Web service, the default Web service name is
     * set automatically.
     * @return a Web service name.
     * @see #invoke(String, Object[])
     * @see #initPortFromURL(URL)
     */
    public String defaultServiceName() {
        if (_defaultServiceName == null || _defaultServiceName == "") {
            NSArray service_names = _port.serviceNames();
            if (service_names.count() == 1) {
                setDefaultServiceName((String)service_names.objectAtIndex(0));
            }
            else {
                setDefaultServiceName("");
            }
        }
        return _defaultServiceName;
    }

    /**
     * Sets the name of the Web service that the invoke(String, Object[]) method uses.
     * @see #invoke(String, Object[])
     * @see #initPortFromURL(URL)
     */
    public void setDefaultServiceName(String serviceName) {
        _defaultServiceName = serviceName.trim();
    }
    
    public void initPortFromAddress(String address) {
        URL url;
        try {
            url = new URL(address);
        }
        catch (MalformedURLException e) {
            throw new IllegalArgumentException("WSDL document cannot be found at URL specified.");
        }

        initPortFromURL(url);
        _address = address;
    }

    public void initPortFromURL(URL url) {
        // API: WOWebServiceClient.WOWebServiceClient(URL)
        _port = new WOWebServiceClient(url);
        
        setDefaultServiceName("");
    }
}
