========================================================================
    CONSOLE APPLICATION : ASCIIMoviePlayerSample Project Overview
========================================================================
Bring back the glory days of ASCII art with ASCIIMoviePlayer! This sample demonstrates using a MovieDrawingCompleteProc to render a QuickTime movie in the Mac OS X Terminal or the DOS Console on Windows. Yes, it's true, now you can enjoy the latest QuickTime Movie Trailers without leaving the comfort of the command line.

ASCIIMoviePlayerSample.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

ASCIIMoviePlayerSample.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named ASCIIMoviePlayerSample.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

Top X Tips for better ASCII QuickTime Movie Viewing
10) Grow your terminal/console to fit the Movie
9) Ask marketing folks if you can incorporate this code into your latest QuickTime product and see if they think you're serious, then do it behind their back anyway
8) Set your terminal to White on Black for optimal look
7) Download your favorite movie trailer
6) While you're at it, download some Graphics Importer sample code (why not?)
5) Jedi mind trick your manager "...you want to send me to WWDC"
4) Order the pizza.
3) Dim the lights and turn up the audio
2) Turn off terminal transparancy for fastest performance
1a) Usage [smelltheglove:/Volumes/Spock] moof% ASCIIMoviePlayer sillymovie.mov
1b) Usage C:\ ASCIIMoviePlayer.exe sillymovie.mov

/////////////////////////////////////////////////////////////////////////////
