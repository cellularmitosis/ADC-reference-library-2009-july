//
// Hello.java: Class file for WO Component 'Hello'
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoaccess.*;

public class Hello extends WOComponent {

    public Hello(WOContext context) {
        super(context);
    }

}
