#include <sys/types.h>
#include <sys/mman.h>
#include <sys/dirent.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>

char *create_shm_file(char *progname, int length)
{
    int fd, i;
    char *filename=malloc(MAXNAMLEN+1);
    char *ret;
    char byte = 0;

    sprintf(filename, "/tmp/%s-XXXXXXXX", progname);
    ret = mktemp(filename);

    fd = open(filename, O_RDWR|O_CREAT, 0600);
    for (i=0; i<length; i++) {
	write(fd, &byte, 1);
    }
    return ret;
}

void *map_shm_file(char *filename, int length)
{
    int fd = open(filename, O_RDWR, 0);
    void *map;
    if (fd == -1) return NULL; /* Could not open file */
    map = mmap(NULL, length, PROT_READ|PROT_WRITE,
        MAP_FILE|MAP_SHARED, fd, 0);
    return map;
}

typedef struct ringbuffer {
    void *buffer;
    int buflen;
    int readpos;
    int writepos;
} *ringbuffer;
#define BYTES_TO_READ(ringbuffer) (ringbuffer->writepos - \
    ringbuffer->readpos + \
    ((ringbuffer->readpos > ringbuffer->writepos) * \
        (ringbuffer->buflen)))

#define BYTES_TO_WRITE(ringbuffer) (ringbuffer->readpos - \
    ringbuffer->writepos + \
    ((ringbuffer->writepos >= ringbuffer->readpos) * \
        ringbuffer->buflen) - 1)


#define SHMLENGTH 2048
main()
{
	char *name = create_shm_file("Myname", SHMLENGTH);
	ringbuffer buf = malloc(sizeof(*buf));

	buf->buflen = 9;
	buf->readpos = 3;
	buf->writepos = 7;
	printf("%d %d\n", BYTES_TO_READ(buf), BYTES_TO_WRITE(buf));

	buf->buflen = 9;
	buf->readpos = 3;
	buf->writepos = 3;
	printf("%d %d\n", BYTES_TO_READ(buf), BYTES_TO_WRITE(buf));

	printf("Mapping shared file %s\n", name);

	{
		int *buf1 = (int *)map_shm_file(name, SHMLENGTH);
		int *buf2 = (int *)map_shm_file(name, 2048);

		printf("%p %p\n", buf1, buf2);
		*buf1 = 0xdeadbeef;
		printf("0x%x\n", *buf2);
	}

}

