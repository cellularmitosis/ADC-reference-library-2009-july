//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HackTV.rc
//
#define IDS_APPNAME                     1
#define IDM_PAGE_SETUP                  40001
#define IDM_PRINT                       40002
#define IDM_EXIT                        40003
#define IDM_UNDO                        40004
#define IDM_CUT                         40005
#define IDM_COPY                        40006
#define IDM_PASTE                       40007
#define IDM_DELETE                      40008
#define IDM_VIDEO_SETTINGS              40009
#define IDM_SOUND_SETTINGS              40010
#define IDM_RECORD_VIDEO                40011
#define IDM_RECORD_SOUND                40012
#define IDM_SPLIT_TRACKS                40013
#define IDM_QUARTER_SIZE                40014
#define IDM_HALF_SIZE                   40015
#define IDM_FULL_SIZE                   40016
#define IDM_RECORD                      40017
#define IDM_WINDOWTILE                  40018
#define IDM_WINDOWCASCADE               40019
#define IDM_WINDOWICONS                 40020
#define IDM_WINDOWCLOSEALL              40021
#define IDM_ABOUT                       40022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40023
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
