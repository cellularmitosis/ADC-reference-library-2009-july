/*
        MouseOverTextView.h
        LayoutManagerDemo

        Author: DD
*/

#import <AppKit/AppKit.h>

@interface MouseOverTextView : NSTextView {
}

@end
