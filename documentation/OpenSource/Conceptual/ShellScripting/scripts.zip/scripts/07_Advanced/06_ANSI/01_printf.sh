#!/bin/sh

printf "\ec" # resets the screen

