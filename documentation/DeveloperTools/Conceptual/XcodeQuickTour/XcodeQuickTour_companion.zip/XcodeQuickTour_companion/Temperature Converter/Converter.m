//
//  Converter.m
//  Converter
//
//  Copyright 2008, Apple Inc. All rights reserved.
//

#import "Converter.h"

@implementation Converter

@synthesize fahrenheit;

- (float) convertToCelsius {
    return (self.fahrenheit - 32.0) * 0.555556;
}

@end