MRJToolkitStubs
v 1.0.1

This sample contains a current MRJToolkitStubs.zip library with empty implementations and definitions of the MRJToolkit classes and interfaces that are part of Apple's J2SE 1.3.1 distribution.

This file is for developers who are building or distributing on non-Mac OS X systems and need definitions of these methods and classes for proper compilation and execution.

For an example of how to use the stubs, open a new Java Swing Application in Project Builder on Mac OS X.

[02/12/2003]