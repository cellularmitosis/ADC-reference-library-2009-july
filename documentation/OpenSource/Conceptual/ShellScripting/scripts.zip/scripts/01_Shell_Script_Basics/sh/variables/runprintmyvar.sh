#!/bin/sh

MYVAR=7 ./printmyvar.sh
echo "MYVAR IS $MYVAR"

