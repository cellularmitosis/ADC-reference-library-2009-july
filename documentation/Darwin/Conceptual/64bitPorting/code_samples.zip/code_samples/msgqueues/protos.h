
Qmessage *msg_reply(comm_channel *channel, Qmessage *message, msg_flags flags);
Qmessage *msg_send(comm_channel *channel, uint8_t type, void *data, uint64_t datalen, msg_flags flags);
int handle_message(comm_channel *channel);
void msg_listen(comm_channel *channel, int exit_on_close);

Qmessage *msg_send_priv(comm_channel *channel, uint8_t type_parm, void *data, uint64_t datalen_parm, msg_flags flags, uint64_t replyid_parm);

