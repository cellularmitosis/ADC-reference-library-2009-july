
#import <AppKit/Appkit.h>


@interface TransparentButtonCell : NSButtonCell {
    NSImage *alphaImage;
}

@end
