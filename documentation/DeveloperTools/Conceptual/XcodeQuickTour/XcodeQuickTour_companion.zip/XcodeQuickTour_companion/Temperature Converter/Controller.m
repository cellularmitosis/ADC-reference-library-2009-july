//
//  Controller.m
//  Converter
//
//  Copyright 2008, Apple Inc. All rights reserved.
//

#import "Controller.h"
#import "Converter.h"

@implementation Controller

- (IBAction) convert:(id)sender {
    Converter *converter = [[Converter alloc] init];
    [converter setFahrenheit:[fahrenheitField floatValue]];
    float celsius = [converter convertToCelsius];
	[celsiusField setStringValue:[NSString stringWithFormat:@"%.2f", celsius]];
	[fahrenheitField selectText:self];
	[converter release];
}

- (BOOL) applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return YES;
}

@end
