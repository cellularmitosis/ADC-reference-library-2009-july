//
//  main.m
//  CoreRecipesApp
//
//  Created by Matt Firlik on 5/8/05.
//  Copyright Apple Computer, Inc 2005. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
