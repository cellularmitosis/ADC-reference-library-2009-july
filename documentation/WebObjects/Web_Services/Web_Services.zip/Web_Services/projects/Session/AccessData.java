//
//  AccessData.java
//  Session
//

import org.apache.axis.MessageContext;

import com.webobjects.appserver.*;
import com.webobjects.foundation.*;

/**
 * Implements the AccessData Web service.
 */
public class AccessData {

    /**
     * Obtains the value of the USER_NAME property from the session.
     * @return user name.
     */
    public String userName() {
        String userName = null;
        WOSession session = serviceSession();
        if (session != null) {
            userName = (String)session.objectForKey(LogIn.USER_NAME);
        }
        return userName;
    }
    
    /**
     * Obtains the value of the USER_PASSWORD property from the session.
     * @return user password.
     */
    public String userPassword() {
        String userPassword = null;
        WOSession session = serviceSession();
        if (session != null) {
            userPassword = (String)session.objectForKey(LogIn.USER_PASSWORD);
        }
        return userPassword;
    }

    /**
     * Retrieves the session from the current context.
     * @return current context's session.
     */
    private WOSession serviceSession() {
        WOContext context = (WOContext)MessageContext.getCurrentContext().getProperty("com.webobjects.appserver.WOContext");
        WOSession session = context.session();
        return session;
    }
}
