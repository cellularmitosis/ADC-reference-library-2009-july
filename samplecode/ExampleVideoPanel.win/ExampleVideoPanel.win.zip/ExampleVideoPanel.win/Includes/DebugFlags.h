/*
	File:		DebugFlags.h

	Contains:	Debug flags.

	Written by:	Gary Woodcock

	Copyright:	� 1992 by Gary Woodcock, all rights reserved.

	Change History (most recent first):

*/

//-----------------------------------------------------------------------

#ifndef _DEBUGFLAGS_
#define	_DEBUGFLAGS_

//-----------------------------------------------------------------------
// flags

// Comment out this flag when building a standalone component
//#define DEBUG_ME	

//-----------------------------------------------------------------------

#endif _DEBUGFLAGS_

//-----------------------------------------------------------------------

