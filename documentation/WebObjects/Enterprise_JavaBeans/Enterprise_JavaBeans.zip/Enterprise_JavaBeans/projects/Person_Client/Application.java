//
// Application.java
// Project Person_Client
//

import my.ejb.Person;
import my.ejb.PersonHome;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;

public class Application extends WOApplication {

    private PersonHome _personHome = null;

    public static void main(String argv[]) {
        WOApplication.main(argv, Application.class);
    }

    public Application() {
        super();
        System.out.println("Welcome to " + this.name() + "!");
        
        // Create Person records.
        createPeople();
        
        // Show Person records.
        showPeople();
        
        // Remove Person records.
        removePeople();
    }

    /**
     * Creates Person records.
     */
    public void createPeople() {
        System.out.println();
        System.out.println("Creating Person records.");
        
        String[] names = {"Susana", "Charles", "Maria", "August"};
        NSArray personNames = new NSArray(names);
        for (int id = 1; id <= personNames.count(); id++) {
            addPerson(id, (String)personNames.objectAtIndex(id - 1));
        }
        System.out.println();
    }
    
    /**
     * Displays Person records.
     */
    public void showPeople() {
        System.out.println("Showing Person records:");
        for (int id = 1; ; id++) {
            try {
                Integer personID = new Integer(id);
                Person person = personHome().findByPrimaryKey(personID);
                System.out.println("Name: " + person.getPersonName());
            }
            catch (FinderException fe) {
                break;
            }
            catch (RemoteException re) {
                re.printStackTrace();
            }
        }
        System.out.println();
    }
    
    /**
     * Removes Person records.
     */
    public void removePeople() {
        int id = 1;
        System.out.println("Removing Person records:");
        while (removePerson(id++));
        System.out.println();
    }

    /**
     * Adds a Person record.
     */
    public void addPerson(int id, String name) {
        try {
            Integer personID = new Integer(id);
            if (personIDIsAvailable(personID)) {
                Person person = personHome().create(personID, name);
                System.out.println("Added " + name + ".");
            }
            else {
                System.out.println(name + " not added because ID " + personID + " is in use.");
            }
        }
        catch (RemoteException re) {
            re.printStackTrace();
        }
        catch (CreateException ce) {
            // Unable to create record: Do nothing.
        }
    } 

    /**
     * Removes a Person record.
     * @return <code>true</code> when successful, <code>false</code> otherwise. 
     */
    public boolean removePerson(int id) {
        boolean removed = false;
        try {
            Integer personID = new Integer(id);
            
            // FinderException is thrown when the record doesn't exist.
            Person person = personHome().findByPrimaryKey(personID);
            
            System.out.println("Deleting " + person.getPersonName() + ".");
            personHome().remove(personID);
            removed = true;
        }
        catch (FinderException fe) {
            // Record not found: Do nothing.
        }
        catch (RemoteException re) {
            re.printStackTrace();
        }
        catch (RemoveException re) {
            re.printStackTrace();
        }
       return removed;
    }

    /**
     * Determines whether a personID has been used.
     * @param personID the value to check;
     * @return <code>true</code> when personID is available, <code>false</code> otherwise.
     */
    public boolean personIDIsAvailable(Integer personID) {
        boolean personID_available = true;
        try {
            personHome().findByPrimaryKey(personID);
            personID_available = false;
        }
        catch (FinderException fe) {
            // personID is available: Do nothing.
        }
        catch (RemoteException re) {
            re.printStackTrace();
            personID_available = false;
        }
        return personID_available;
    }
    
    /**
     * Obtains Person's home interface.
     * @return Person's home interface.
     */
    public PersonHome personHome() {
        if (_personHome == null) {
            try {
                Context jndiContext = new InitialContext();
                _personHome = (PersonHome)PortableRemoteObject.narrow(jndiContext.lookup("PersonCMP"), PersonHome.class);
            }
            catch (NamingException ne) {
                ne.printStackTrace();
            }
        }
        return _personHome;
    }
}
