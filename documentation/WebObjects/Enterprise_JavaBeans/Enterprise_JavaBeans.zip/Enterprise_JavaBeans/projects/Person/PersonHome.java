

package my.ejb;

import java.rmi.RemoteException;
import javax.ejb.FinderException;
import javax.ejb.CreateException;

public interface PersonHome extends javax.ejb.EJBHome {

 
  /**
   * This method creates a new entity from all required attributes
   * @throws javax.ejb.CreateException
   * @throws java.rmi.RemoteException
   * @returns a reference to the new bean instance 
   */
  public Person create(java.lang.Integer person_ID) throws RemoteException, CreateException;


  /**
   * This method creates a new entity from all attributes
   * @throws javax.ejb.CreateException
   * @throws java.rmi.RemoteException
   * @returns a reference to the new bean instance 
   */
  public Person create(java.lang.Integer person_ID, java.lang.String personName) throws RemoteException, CreateException;

 
  /**
   * This method returns all entities in this table
   * @returns all entities in the table in a java.util.Collection
   * @throws javax.ejb.FinderException if there are problems connecting to the database or executing the query
   * @throws java.rmi.RemoteException
   */
  public java.util.Collection findAll() throws RemoteException, FinderException;


  /**
   * This method returns the bean associated with the primaryKey argument, or throws a javax.ejb.ObjectNotFoundException
   * @returns the bean associated with the primaryKey argument
   * @throws javax.ejb.ObjectNotFoundException if an entity with the given primary key doesn't exist
   * @throws java.rmi.RemoteException
   */
  public Person findByPrimaryKey(java.lang.Integer primaryKey) throws RemoteException, FinderException;
}
