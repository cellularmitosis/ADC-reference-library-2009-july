//
// Prefix header for all source files of the 'NSOpenGLFullScreen' target in the 'NSOpenGLFullScreen' project
//

#ifdef __OBJC__
    #import <Cocoa/Cocoa.h>
#endif
