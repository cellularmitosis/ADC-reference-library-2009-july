README - QTSndTween

QTSndTween.c defines functions that illustrate how to modify an existing QuickTime
movie so that the volume of its sound track is gradually increased (or decreased)
as the movie plays. We do this by adding a tween track to the movie and linking the
tween track to the existing sound track.

Enjoy,
QuickTime Team
