Successor of "CarbonDraw", where the name hints at 
    /Developer/Examples/AppKit/Sketch/.

In contrast to the old CarbonDraw, there is no Quickdraw API being used;
and in contrast to AppKit/Sketch, it is a HIToolbox-based Carbon application.

Demonstrates the usage of an overlay window for mouse-tracking feedback, 
and the usage of a 1x1-CGBitmapContext for hit-testing.

Includes support for printing, and a separate item "Save As PDF File".
Now also demonstrates Copy/Paste of pdf data.
