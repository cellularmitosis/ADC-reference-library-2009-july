README - MakeEffectMovie

This application takes the video tracks from zero, one, or two movies 
and creates a new movie with an effects track for them.

Try it out: drag two short movies of the same size onto the application icon.
Or, alternatively, launch the application and choose them from the 
Open... dialog.

Enjoy,
QuickTime Team

