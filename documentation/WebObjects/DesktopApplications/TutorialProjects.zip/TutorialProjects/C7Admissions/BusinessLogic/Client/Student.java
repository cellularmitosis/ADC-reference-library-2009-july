// Student.java
// Created on Tue Aug 27 17:14:53 US/Pacific 2002 by Apple EOModeler Version 5.2

package businesslogic.client;

import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;
import java.math.BigDecimal;
import java.util.*;

public class Student extends EOGenericRecord {

    public Student() {
        super();
    }

/*
    // If you implement the following constructor EOF will use it to
    // create your objects, otherwise it will use the default
    // constructor. For maximum performance, you should only
    // implement this constructor if you depend on the arguments.
    public Student(EOEditingContext context, EOClassDescription classDesc, EOGlobalID gid) {
        super(context, classDesc, gid);
    }
*/


    public Number sat() {
        return (Number)storedValueForKey("sat");
    }

    public void setSat(Number value) {
        takeStoredValueForKey(value, "sat");
    }

    public String name() {
        return (String)storedValueForKey("name");
    }

    public void setName(String value) {
        takeStoredValueForKey(value, "name");
    }

    public Number gpa() {
        return (Number)storedValueForKey("gpa");
    }

    public void setGpa(Number value) {
        takeStoredValueForKey(value, "gpa");
    }

    public Number act() {
        return (Number)storedValueForKey("act");
    }

    public void setAct(Number value) {
        takeStoredValueForKey(value, "act");
    }

    public NSTimestamp firstContact() {
        return (NSTimestamp)storedValueForKey("firstContact");
    }

    public void setFirstContact(NSTimestamp value) {
        takeStoredValueForKey(value, "firstContact");
    }

    public NSArray activities() {
        return (NSArray)storedValueForKey("activities");
    }

    public void setActivities(NSArray value) {
        takeStoredValueForKey(value, "activities");
    }

    public void addToActivities(businesslogic.client.Activity object) {
        includeObjectIntoPropertyWithKey(object, "activities");
    }

    public void removeFromActivities(businesslogic.client.Activity object) {
        excludeObjectFromPropertyWithKey(object, "activities");
    }
    
     public Number rating() {
        return (Number)(invokeRemoteMethod("clientSideRequestRating", null, null));
    }
}
