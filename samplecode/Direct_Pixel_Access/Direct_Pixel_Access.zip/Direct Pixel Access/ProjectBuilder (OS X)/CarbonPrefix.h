#ifndef __CARBONPREFIX__
#define __CARBONPREFIX__


// Needed for carbonization
#define TARGET_API_MAC_CARBON 1
//

// For the pascal to C or C to pascal string conversions in carbon
#define OLDP2C 1
//

#endif