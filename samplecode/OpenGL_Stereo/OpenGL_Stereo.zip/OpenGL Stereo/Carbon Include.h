// Carbon Include.h

// Put Carbon specific stuff here to maintain 9/Carbon buildability...


#define TARGET_API_MAC_CARBON 1