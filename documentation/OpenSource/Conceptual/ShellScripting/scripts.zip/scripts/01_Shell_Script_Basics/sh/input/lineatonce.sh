#!/bin/sh
IFS="
"
read LINE
echo "Line was \"$LINE\"."
