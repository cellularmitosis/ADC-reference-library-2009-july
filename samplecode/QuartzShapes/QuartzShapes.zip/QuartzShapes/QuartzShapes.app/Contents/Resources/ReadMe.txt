QuartzShapes

Provides example functions for drawing shapes to a Core Graphics context, and show how to use them to draw in an Carbon HIView. The example functions that are implemented are equivalents to the QuickDraw PaintArc, FrameArc, PaintOval, FrameOval, PaintRect, and FrameRect.  There is also a function to create rounded rectangles like Mac OS X's windows.