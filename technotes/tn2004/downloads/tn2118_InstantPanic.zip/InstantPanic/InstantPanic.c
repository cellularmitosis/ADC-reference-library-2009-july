#include <mach/mach_types.h>
#include <sys/systm.h>

extern kern_return_t com_apple_dts_InstantPanic_start(kmod_info_t * ki, void * d);
extern kern_return_t com_apple_dts_InstantPanic_stop(kmod_info_t * ki, void * d);

kern_return_t com_apple_dts_InstantPanic_start(kmod_info_t * ki, void * d)
{
    panic("InstantPanic: Just add water!");
    return KERN_SUCCESS;
}


kern_return_t com_apple_dts_InstantPanic_stop(kmod_info_t * ki, void * d)
{
    return KERN_SUCCESS;
}
