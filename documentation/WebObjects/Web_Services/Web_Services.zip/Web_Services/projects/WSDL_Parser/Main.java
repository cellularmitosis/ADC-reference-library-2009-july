//
// Main.java: Class file for WO Component 'Main'
// Project WSDL_Parser
//

import java.net.MalformedURLException;
import java.net.URL;

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.webservices.client.*;

public class Main extends WOComponent {
    private WebServicePort _port = null;
    protected String address = null;
    protected String message;
    
    public String serviceName;

    public WOWebService service;
    public WOClientOperation operation;
    public WOClientParameter parameter;


    public Main(WOContext context) {
        super(context);
    }
    
    public String serviceName() {
        return service.name();
    }
    
    public String operationName() {
        return operation.name();
    }
    
    public String operationStyle() {
        return operation.style();
    }
    
    public String parameterName() {
        return parameter.name();
    }

    public String parameterType() {
        return parameter.typeQName().toString();
    }

    public String parameterMode() {
        return parameter.parameterMode().toString();
    }
    
    /** @TypeInfo com.webobjects.webservices.client.WOWebService */
    public NSArray services() {
        NSArray services = null;
        if (_port != null) {
        	services = _port.services();
        }
        return services;
    }
    
    /** @TypeInfo com.webobjects.webservices.client.WOClientOperation */
    public NSArray operationsForService() {
        return _port.operationsForService(serviceName());
    }

    /** @TypeInfo com.webobjects.webservices.client.WOClientParameter */
    public NSArray parametersForOperation() {
        NSArray parameters = (NSArray)operation.parameters();
        return parameters;
    }

    /** @TypeInfo com.webobjects.webservices.client.WOClientParameter */
    public NSArray returnValuesForOperation() {
        NSArray returnValues = (NSArray)operation.returnTypes();
        return returnValues;
    }
    
    public WOComponent parseWSDL() {
        message = "";
        String wsdl_address = address.trim();
        if (wsdl_address != null && wsdl_address.length() > 0) {
            try {
                URL url = new URL(wsdl_address);
                _port = new WebServicePort(wsdl_address);
           }
            catch (MalformedURLException e) {
                _port = null;
                message = "Invalid URL.";
            }
            catch (Exception e) {
                _port = null;
                message = "Unable create connection to Web service.";
            }
        }
        return null;
    }    
}
