README - QTFullScreen

QTFullScreen.c defines functions that illustrate how to play QuickTime movies full screen.
The key elements to displaying full screen movies are the calls BeginFullScreen and EndFullScreen,
introduced in QuickTime 2.5. Here we open a QuickTime movie, configure it to play full screen,
associate a movie controller, and then let the controller handle events. Your application should
call the function QTFullScreen_EventLoopAction in its event loop (on MacOS) or when it gets
idle events (on Windows).

Enjoy,
QuickTime Team

