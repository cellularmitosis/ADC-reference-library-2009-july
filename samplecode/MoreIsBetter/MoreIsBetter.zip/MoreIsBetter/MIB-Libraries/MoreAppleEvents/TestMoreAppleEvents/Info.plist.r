read 'plst' (0) "info.plist";
