//
// Report.java: Class file for WO Component 'Report'
// Project Admissions
//
// Created by bshank on Wed Aug 28 2002
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoaccess.*;

public class Report extends WOComponent {

        /** @TypeInfo Student */
        protected EOEnterpriseObject student;

        /** @TypeInfo Activity */
        protected EOEnterpriseObject activity;

    public Report(WOContext context) {
        super(context);
    }

        public void setStudent(EOEnterpriseObject newStudent)
        {
                student = newStudent;
        }

}
