//
//  main.m
//  RGB ValueTransformers
//
//  Created by jcr on Thu Nov 06 2003.
//  Copyright (c) 2003 Apple Computer, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
