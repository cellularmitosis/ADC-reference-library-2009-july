//
// FavoriteFood.java: Class file for WO Component 'FavoriteFood'
// Project JSP_Example
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoaccess.*;

public class FavoriteFood extends WOComponent {
    protected String visitorName;
    protected String favoriteFood;

    public FavoriteFood(WOContext context) {
        super(context);
    }

    public String visitorName()
    {
        return visitorName;
    }
    public void setVisitorName(String newVisitorName)
    {
        visitorName = newVisitorName;
    }

    public String favoriteFood()
    {
        return favoriteFood;
    }
    public void setFavoriteFood(String newFavoriteFood)
    {
        favoriteFood = newFavoriteFood;
    }

}
