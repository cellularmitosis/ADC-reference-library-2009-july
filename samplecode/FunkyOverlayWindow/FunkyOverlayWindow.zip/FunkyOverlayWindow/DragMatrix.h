

#import <Cocoa/Cocoa.h>

@interface DragMatrix : NSMatrix
{
}
@end
