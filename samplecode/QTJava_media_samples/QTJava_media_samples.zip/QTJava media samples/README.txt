=============================================================================
QuickTime for Java SDK                              Updated: 30 November 1998

Read Me Notes to "media" package.

=============================================================================
This is a collection of media files common to many of the QuickTime for Java samples.  This package is required in order to use the samples.

=============================================================================

QuickTime and QuickTime for Java are trademarks of Apple Computer, Inc.
(c) 1998 Apple Computer Inc. All rights reserved.
