The "Build All" target (the default) will compile both the Client and Server command-line programs.

Run Server from one Terminal window.  Then run Client in another.  The Client program takes two command-line arguments, floating point numbers, like this:

% build/Client 6.5 7.21
2005-05-31 16:00:33.365 Client[477] getting response
2005-05-31 16:00:33.378 Client[477] result: 13.71

