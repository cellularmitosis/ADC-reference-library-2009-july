//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by QD3DSample.RC
//
#define IDR_GENERIC                     101
#define IDI_APP                         102
#define IDD_ABOUTBOX                    103
#define IDI_Q3X                         103
#define IDC_FILEDESCRIPTION             1000
#define IDC_PRODUCTVERSION              1001
#define IDC_LEGALCOPYRIGHT              1002
#define IDC_COMPANYNAME                 1003
#define IDC_LEGALTRADEMARKS             1004
#define IDM_EXIT                        40007
#define IDM_ABOUT                       40017
#define ID_FILE_OPEN_MMF                40018
#define ID_QD3D_RENDERER_INTERACTIVE    40019
#define ID_QD3D_RENDERER_WIREFRAME      40020
#define ID_QD3D_DRAWCONTEXT_PIXMAP16BIT555 40021
#define ID_QD3D_DRAWCONTEXT_WIN32DC     40022
#define ID_QD3D_DRAWCONTEXT_DIRECTDRAW  40023
#define ID_QD3D_CLEARCOLOR              40024
#define ID_QD3D_SPIN                    40025
#define ID_QD3D_DRAWCONTEXT_PIXMAP16BIT565 40026
#define ID_QD3D_DRAWCONTEXT_PIXMAP24BIT 40027
#define ID_QD3D_DRAWCONTEXT_PIXMAP32BIT 40028
#define ID_FILE_OPEN_WIN32              40029
#define ID_FILE_OPEN_PATH               40030
#define ID_FILE_OPEN_UNIX               40031
#define ID_FILE_SAVE_WIN32              40033
#define ID_FILE_SAVE_PATH               40035
#define ID_FILE_SAVE_UNIX               40036
#define ID_FILE_SAVE_WIN32_TEXT         40037
#define ID_FILE_SAVE_PATH_TEXT          40038
#define ID_FILE_SAVE_UNIX_TEXT          40039
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40040
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
