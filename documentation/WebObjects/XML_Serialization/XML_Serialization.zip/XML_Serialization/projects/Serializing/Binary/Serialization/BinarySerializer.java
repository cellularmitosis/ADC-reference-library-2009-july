//
// Serializer.java
// Project Serialization
//
// Created by The_Mole.
//

import com.webobjects.appserver.*;
import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.ClassNotFoundException;

/**
 * Manages serialization and deserialization of objects
 * to and from binary files.
 */
public class BinarySerializer {
    /**
     * Encapsulates a file stream and an object stream (a channel).
     */
    private static class Channel {
	protected Object file_stream;
	protected Object object_stream;
	protected boolean input_stream;

	Channel(Object file_stream, Object object_stream, boolean input_stream) {
	    this.file_stream = file_stream;
	    this.object_stream = object_stream;
	    this.input_stream = input_stream;
	}
    }
    
    /**
     * Stores open channels.
     */
    private static NSMutableDictionary channels = new NSMutableDictionary();
    
    /**
     * Directory in which serialized data intended for
     * deserialization is stored.
     */
    private static final String FILE_PREFIX = "/tmp/";

    /**
     * Suffix (including extension) of files used to store serialized data.
     */
    private static final String FILE_SUFFIX = "_data.binary";

    /**
     * Serializes data to a file.
     *
     * @param source          object to serialize
     * @param identifier      file identifier for deserialization
     *                        (name of the file without the extension)
     *
     * @return <code>true</code> when the process succeeds.
     */
    public static boolean serializeObject(Object source, String identifier) {
	ObjectOutputStream binary_stream;
	String filename = FILE_PREFIX + identifier + FILE_SUFFIX;
	boolean success = false;

	try {
	    // Create a stream to the output file.
	    binary_stream = (ObjectOutputStream)BinarySerializer.openStream(filename, false);

	    // Serialize data to output stream.
	    binary_stream.writeObject(source);

	    // Close the stream.
	    binary_stream.flush();
	    closeStream(filename);
	    
	    success = true;
	}

	catch (IOException e) {
	    e.printStackTrace();
	}

	return success;
    }

    /**
     * Deserializes data from a file.
     *
     * @param identifier      file identifier (name of the file without
     *                        the extension)
     *
     * @return deserialized object.
     */
    public static Object deserializeObject(String identifier) {
	ObjectInputStream binary_stream;
	String filename = FILE_PREFIX + identifier + FILE_SUFFIX;
	Object object = null;

	try {
	    // Create a stream from the input file.
	    binary_stream = (ObjectInputStream)openStream(filename, true);

	    // Deserialize data from input stream.
	    object = (Object)binary_stream.readObject();

	    // Close the stream.
	    closeStream(filename);
	}

	catch (IOException e) {
	    e.printStackTrace();
	}
	catch (ClassNotFoundException e) {
	    e.printStackTrace();
	}
	
	return object;
    }

    /**
     * Opens an output stream.
     *
     * @param filename          fully qualified filename of the
     *                          target or source file; identifies
     *                          the channel to open.
     */
    public static ObjectOutputStream openOutputStream(String filename) throws IOException {
	return (ObjectOutputStream)openStream(filename, false);
    }

    /**
     * Opens an input stream.
     *
     * @param filename           fully qualified filename of the
     *                           target or source file; identifies
     *                           the channel to open.
     */
    public static ObjectInputStream openInputStream(String filename) throws IOException {
	return (ObjectInputStream)openStream(filename, true);
    }

    /**
     * Opens a file stream to or from a file and a corresponding
     * output or input object stream.
     * The method adds the pair of streams to an internal dictionary
     * for use by the <code>closeStream</code> method.
     *
     * @param filename           fully qualified filename of the
     *                           target or source file; identifies
     *                           the channel to open.
     * @param input_stream       indicates whether the stream returned
     *                           is an input stream or an output stream:
     *                           <code>true</code> for an input stream and
     *                           <code>false</code> for an output stream.
     *
     * @return object stream, <code>null</code> when the stream could not
     *         be created.
     */
    private static Object openStream(String filename, boolean input_stream) throws IOException {
	BufferedOutputStream file_output_stream = null;
	BufferedInputStream file_input_stream = null;
	Channel channel;
	Object binary_stream = null;

	if (input_stream) {
	    // Create an input stream from the file.
	    file_input_stream = new BufferedInputStream(new FileInputStream(filename));

	    // Create object-input stream.
	    binary_stream = new ObjectInputStream(file_input_stream);

	    channel = new Channel(file_input_stream, binary_stream, input_stream);
	} else {
	    // Create an output stream to the file.
	    file_output_stream = new BufferedOutputStream(new FileOutputStream(filename));

	    // Create object-output stream.
	    binary_stream = new ObjectOutputStream(file_output_stream);

	    channel = new Channel(file_output_stream, binary_stream, input_stream);
	}
	channels.setObjectForKey(channel, filename);

	return binary_stream;
    }

    /**
     * Closes an object stream and its corresponding file stream.
     *
     * @param filename             fully qualified filename of the
     *                             target or source file; identifies
     *                             the streams to close.
     */
    public static void closeStream(String filename) throws IOException {
	Channel channel = (Channel)channels.objectForKey(filename);
	
	if (channel.input_stream) {
	    ((ObjectInputStream)channel.object_stream).close();
	    ((BufferedInputStream)channel.file_stream).close();
	} else {
	    ((ObjectOutputStream)channel.object_stream).close();
	    ((BufferedOutputStream)channel.file_stream).close();
	}
	
	channels.removeObjectForKey(filename);
    }    
}