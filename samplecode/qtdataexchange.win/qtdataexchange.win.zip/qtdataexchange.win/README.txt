README - QTDataEx

QTDataEx is a sample application that illustrates
the most basic ways of using QuickTime's movie importers
and exporters (data exchange components). It shows how to
import files that are not QuickTime movie files, how to
export a movie into any format supported by QuickTime's
movie exporters, and how to export a movie as a hinted
movie file. It also illustrates how to use a
custom movie progress function.

Enjoy, 

QuickTime Team