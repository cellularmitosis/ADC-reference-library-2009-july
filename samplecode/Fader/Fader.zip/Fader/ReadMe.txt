Fader
v2.1

This sample Dashboard widget demonstrates use of the AppleAnimator and AppleAnimation classes provided since Mac OS X 10.4.3 to create a general-purpose object that fades HTML elements in and out of sight.

Inspect the code and comments in the Content folder to learn about the widget's implementation without disrupting the widget bundle.