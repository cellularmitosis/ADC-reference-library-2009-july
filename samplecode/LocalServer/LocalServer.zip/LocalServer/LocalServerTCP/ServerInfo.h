/*
 *  ServerInfo.h
 *  LocalServer
 *
 *  Created by admin on Tue Apr 09 2002.
 *  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
 *
 */

#define kMyCustomSelector	'RKRK'
#define kPassServerInfoClass	'PASS'
#define kPassServerInfoEvent	'Pass'
#define kPassKeyword		'Pass'
#define kPassServerType		'Pass'
#define kApplicationFileType	'APPL'
#define kPassServerSignature	'LOCL'

