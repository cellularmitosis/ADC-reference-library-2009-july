ExampleVideoPanel Sample Code

Version 1.0
3/15/02


DESCRIPTION

This is an example of a simple sequence grabber video panel component.

Sequence grabber panel components augment the capabilities of sequence grabber components and sequence grabber channel components by allowing sequence grabbers to obtain configuration information from the user for a particular digitizing source that is managed by a channel component. 

Sequence grabbers present a settings dialog box to the user whenever an application calls the SGSettingsDialog function. Applications never call sequence grabber panel components directly; application developers use panel components only by calling the sequence grabber component. 

Although the sequence grabber creates the dialog box and manages its interactions with the user, portions of the dialog box are controlled by panel components and channel components.

The sequence grabber creates the dialog box itself and manages the OK and Cancel buttons and the panel pop-up menu. Channel components are responsible for the monitor area on the right side of the dialog box. Panel components manage the settings area immediately below the panel pop-up menu. Only one panel component is active at any given time; the user selects a panel component by manipulating the panel pop-up menu.

When the user selects a specific panel component, the sequence grabber works with that component to build the panel settings dialog area and present it to the user. The panel component processes dialog events and mouse clicks as appropriate and validates the user's settings. The sequence grabber then retrieves the settings from the panel component and stores those settings. 

There are two circumstances under which you should consider creating a sequence grabber panel component: first, if you want to support special digitizing equipment in the QuickTime environment; and, second, if you have created your own sequence grabber channel component.

PROGRAM SPECIFICS

This sample lets the user specify the black level value for the underlying vdig component via the VDSetBlackLevelValue function. The panel displays two buttons: Reset and "Do It". Pressing the "Do It" button will set the black level to the maximum value (0) . Pressing the Reset button will restore the black level to its original value. Note that some vdigs do not support the VDSetBlackLevelValue function, in which case the "Do It" button is deactivated.

USING THE SAMPLE

After placing the built component file in the appropriate folder, you can activate the component by calling the SGSettingsDialog function. The HackTV sample code from the QuickTime SDK will do this for you when you select the "Video Settings" menu item from the Monitor menu.

BUILD REQUIREMENTS

CodeWarrior 6, IDE 4.1
Microsoft Visual C++ 6

RUNTIME REQUIREMENTS

QuickTime 4 for Macintosh OS 9
QuickTime 4 Macintosh OS X
QuickTime 4 for Windows 98, ME, 2000, XP

BUILDING THE SAMPLE

Macintosh

The sample builds two targets for Macintosh: 

ExampleVideoPanel PPC - standalone PPC sequence grabber panel component for Traditional Mac OS. Place the target in your System Folder:Extensions folder.

ExampleVideoPanel Carbon - standalone Carbon sequence grabber panel component for Mac OS X. Place the target in your /Library/QuickTime/ folder.

Windows

The sample builds two target for Windows:

ExampleVideoPanel Release - release build, standalone sequence grabber panel component for Windows 98, ME, 2000 or XP. Place the target in your \Windows\System(32)\QuickTime folder.

ExampleVideoPanel Debug - debug build, standalone sequence grabber panel component for Windows 98, ME, 2000 or XP. Place the target in your \Windows\System(32)\QuickTime folder.

FEEDBACK

Send feedback to: <http://developer.apple.com/contact/feedback.html>
