// Person.java
// Created on Tue Sep 17 15:44:39 US/Pacific 2002 by Apple EOModeler Version 5.2

package businesslogic.client;

import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;
import java.math.BigDecimal;
import java.util.*;

public class Person extends EOGenericRecord {

    public Person() {
        super();
    }

/*
    // If you implement the following constructor EOF will use it to
    // create your objects, otherwise it will use the default
    // constructor. For maximum performance, you should only
    // implement this constructor if you depend on the arguments.
    public Person(EOEditingContext context, EOClassDescription classDesc, EOGlobalID gid) {
        super(context, classDesc, gid);
    }
*/


    public String password() {
        return (String)storedValueForKey("password");
    }

    public void setPassword(String value) {
        takeStoredValueForKey(value, "password");
    }
}
