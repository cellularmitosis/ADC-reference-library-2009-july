5/2/08

SampleScannerApp sample 1.0

This project implements a simple client accessing an ICA scanning device.  The project assumes "flat bed" as the default mode.

System requirements:
- Leopard Mac OS X 10.5.x or later.

New features

- removed all deprecated APIs.
- updated to use Leopard's dictionary based notification workflow.

Other References

See the TWAIN specification (http://twain.org) for information about the device capability constants (ICAP_PIXELTYPE, ICAP_BITDEPTH, and so on) used throughout this sample.
