//
//  Clock.java
//  Clock
//

import java.util.*;

public class Clock {

    public static void main (String args[]) {
        Date date = new Date();
        
        if (args.length > 0) {
            String user_name = args[0];
            System.out.println("Hello, " + user_name + ". It's " + date);
        }
        else {
            System.out.println("It's " + date);
        }
    }
}
