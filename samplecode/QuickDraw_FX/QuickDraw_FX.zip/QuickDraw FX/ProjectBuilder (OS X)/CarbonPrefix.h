#ifndef __CARBONPREFIX__
#define __CARBONPREFIX__


// Needed for carbonization
#define TARGET_API_MAC_CARBON 1
//

#define cItem localCItem

// To use the P2C string conversion functions
#define OLDP2C 1
//

#endif