#!/bin/sh
# Save as sourcetest1.sh
MYVAR=3
source sourcetest2.sh
echo "MYVAR IS $MYVAR"
