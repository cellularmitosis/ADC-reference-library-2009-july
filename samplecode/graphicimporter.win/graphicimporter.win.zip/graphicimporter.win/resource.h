//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GraphicImporter.rc
//
#define IDM_CASCADE                     30
#define IDM_TILE                        31
#define IDM_ARRANGE                     32
#define IDM_CLOSEALL                    33
#define ACCEL_ID                        100
#define IDR_MAINMENU                    101
#define IDR_CHILDMENU                   102
#define MM_OPT_1                        7001
#define MM_OPT_2                        7002
#define MM_OPT_3                        7003
#define MM_OPT_4                        7004
#define MM_OPT_5                        7005
#define MM_OPT_6                        7006
#define MM_OPT_7                        7007
#define MM_OPT_8                        7008
#define MM_ABOUT                        8000
#define MM_MDI                          8001
#define MM_RESERVE1                     8002
#define MM_RESERVE2                     8003
#define MM_EXIT                         8004
#define IDM_HELP_MENU                   8005
#define IDS_HELPMENUTEXT                9000
#define IDI_APP                         10000
#define ID_FILE_EXIT                    40002
#define ID_FILE_CLOSE                   40003
#define ID_CREATE_CLOSE                 40004
#define ID_CREATE_EXLT                  40005
#define ID_FILE_OPEN                    40006
#define ID_WINDOW_ABOUT                 40007
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
