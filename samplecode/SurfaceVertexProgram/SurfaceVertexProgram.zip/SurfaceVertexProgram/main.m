//
//  main.m
//  BasicVertexProgram
//
//  Created by Michael K Larson on Tue Apr 22 2003.
//  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
