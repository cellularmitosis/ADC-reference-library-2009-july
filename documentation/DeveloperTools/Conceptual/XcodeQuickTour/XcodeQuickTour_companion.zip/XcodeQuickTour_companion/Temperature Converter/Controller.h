//
//  Controller.h
//  Converter
//
//  Copyright 2008, Apple Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Controller : NSObject {
	IBOutlet NSTextField *fahrenheitField;
	IBOutlet NSTextField *celsiusField;
}
- (IBAction)convert:(id)sender;

@end
