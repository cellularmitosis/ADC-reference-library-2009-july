//
//  SecurityDelegate.java
//  Security
//

import com.webobjects.appserver.WOWebServiceRegistrar;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;

/**
 * Provides security methods.
 */
public class SecurityDelegate {

    public void processClientRequest(MessageContext mc) throws AxisFault {
        System.out.println("<SecurityDelegate> processClientRequest(MessageContext)");
    }
    
    public void processClientResponse(MessageContext mc) throws AxisFault {
        System.out.println("<SecurityDelegate> processClientResponse(MessageContext)");
    }
    
    public void processServerRequest(MessageContext mc) throws AxisFault {
        System.out.println("<SecurityDelegate> processServerRequest(MessageContext)");
    }
    
    public void processServerResponse(MessageContext mc) throws AxisFault {
        System.out.println("<SecurityDelegate> processServerResponse(MessageContext)");
    }
    
    public void onFaultClientRequest(MessageContext mc){
        System.out.println("<SecurityDelegate> undoClientRequest(MessageContext)");
    }
    
    public void onFaultClientResponse(MessageContext mc){
        System.out.println("<SecurityDelegate> undoClientResponse(MessageContext)");
    }
    
    public void onFaultServerRequest(MessageContext mc){
        System.out.println("<SecurityDelegate> undoServerRequest(MessageContext)");
    }
    
    public void onFaultServerResponse(MessageContext mc){
        System.out.println("<SecurityDelegate> undoServerResponse(MessageContext)");
    }

}
