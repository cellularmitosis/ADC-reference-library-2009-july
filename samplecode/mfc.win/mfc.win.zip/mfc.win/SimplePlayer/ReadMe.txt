========================================================================
       QuickTime 2.5 : SimplePlayer MFC
========================================================================
A Microsoft MFC application that plays a movie with QuickTime

