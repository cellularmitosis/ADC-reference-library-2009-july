#!/bin/sh

STRING="This is a test"
expr "$STRING" : ".*"
