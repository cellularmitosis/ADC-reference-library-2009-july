README - MDIPlayer

MDIPlayer is a sample application that demonstrates how to display QuickTime movies
using the MDI (multiple document interface).

Enjoy,
QuickTime Team

