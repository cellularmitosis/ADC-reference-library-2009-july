//
// Movie.java
// Project Transformation
//
// Created by The_Mole.
//

import com.webobjects.appserver.*;
import com.webobjects.foundation.*;
import com.webobjects.foundation.xml.*;
import com.webobjects.eocontrol.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.Timestamp;

/*
 * Manages movie information.
 */
public class Movie extends Object implements Serializable {
    private String title;
    private String studio;
    private NSTimestamp releaseDate;

    /*
     * Creates a Movie object.
     *
     * @param name          movie title
     * @param studio        studio that released the movie
     * @param release_date  date the movie was released
     */
    Movie(String title, String studio, NSTimestamp releaseDate) {
	super();
	
        setTitle(title);
	setStudio(studio);
	setReleaseDate(releaseDate);
    }

    /*
     * Gets this movie's title.
     *
     * @return movie title.
     */
    public String title() {
	return this.title;
    }
    
    /*
     * Sets this movie's title.
     *
     * @param value            movie's title
     */
    public void setTitle(String value) {
	this.title = value;
    }

    /*
     * Gets this movie's studio.
     *
     * @return movie studio.
     */
    public String studio() {
	return this.studio;
    }

    /*
     * Sets this movie's studio.
     *
     * @param value           studio's name
     */
    public void setStudio(String value) {
	this.studio = value;
    }

    /*
     * Gets this movie's release date.
     *
     * @return movie release date.
     */
    public NSTimestamp releaseDate() {
	return this.releaseDate;
    }

    /*
     * Sets this movie's release date.
     *
     * @param value          release date
     */
    public void setReleaseDate(NSTimestamp value) {
	this.releaseDate = value;
    }

    // String representation.
    /*
     * Gets the string representation of this movie.
     *
     * @return string representing this movie.
     */
    public String toString() {
	return "(Movie: (Title: " + title() + "), (Studio: " + studio() + "), (Release Date: " + releaseDate().toString() +  "))";
    }

    /*
     * Serializes this object.
     *
     * @param stream    object stream to serialize this object to
     */
    private void writeObject(ObjectOutputStream stream) throws IOException {
	// Serialize the object's instance members.
	// (This is where you put special encoding logic,
	// such as the one used to encode the releaseDate field.)
        
        // Cast stream to NSXMLOutputStream to gain access to
        // <code>writeObject(Object, String)</code>.
        NSXMLOutputStream xml_stream = (NSXMLOutputStream)stream;
        
	xml_stream.writeObject(title(), "title");
	xml_stream.writeObject(studio(), "studio");
	xml_stream.writeObject(releaseDate().toString(), "release_date");
    }

    /*
     * Deserializes this object.
     *
     * @param stream   object stream from which the serialized data
     *                 is obtained
     */
    private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
	// Deserializes the data a put it in the object's instance members.
	// (This is where you would put special de-encoding logic
	// such as the one used to decode the releaseDate field.)
	setTitle((String)stream.readObject());
	setStudio((String)stream.readObject());
	setReleaseDate(_timestampFromString((String)stream.readObject()));
    }
    
    /*
     * Converts a string into an NSTimestamp.
     *
     * @param timestampAsString     string to convert
     *
     * @return NSTimestamp object represented by timestampAsString.
     */
    private NSTimestamp _timestampFromString(String timestampAsString) {
	NSTimestampFormatter formatter = new NSTimestampFormatter();
	java.text.ParsePosition pp = new java.text.ParsePosition(0);

	return (NSTimestamp)formatter.parseObject(timestampAsString, pp);
    }
}
