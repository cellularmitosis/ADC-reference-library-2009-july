//
//  CalculatorClient.java
//

import java.net.*;
import java.util.Enumeration;

import com.webobjects.foundation.*;
import com.webobjects.webservices.client.*;

public class CalculatorClient extends Object {
    
    /**
     * Object through which the Web service's operations are invoked.
     */
    private WOWebServiceClient _serviceClient = null;
    
    /**
     * Address for the Web service's WSDL document.
     */
    private String _service_address = "http://localhost:4210/cgi-bin/WebObjects/Calculator.woa/ws/Calculator?wsdl";
    
    /**
     */
    public CalculatorClient() {
        super();
    }

    /**
     * Obtains the Web service's operation names.
     * @return the Web service's operation names.
     */
    public NSArray operations() {
        NSArray operations = (serviceClient().operationsDictionaryForService(serviceName())).allValues();
        NSMutableArray operation_names = new NSMutableArray();
        Enumeration operations_enumerator = operations.objectEnumerator();
        while (operations_enumerator.hasMoreElements()) {
            WOClientOperation operation = (WOClientOperation)operations_enumerator.nextElement();
            operation_names.addObject((String)operation.name());
        }
        return operation_names;
    }
    
    /**
     * Invokes the Web service's operations.
     * @param operation      operation to invoke;
     * @param arguments      argument list;
     * @return               value returned by the operation.
     */
    public Double invoke(String operation, Object[] arguments) {
        Object result = serviceClient().invoke(serviceName(), operation, arguments);
        return (Double)result;
    }

    /**
     * Obtains the Web service name.
     * Normally one WSDL file describes one Web service,
     * but it could describe one or more services.
     * @return Web service name.
     */
    public String serviceName() {
        return (String)serviceClient().serviceNames().objectAtIndex(0);
    }
    
    /**
     * Obtains an agent through which service operations are invoked.
     * @return service agent.
     */
    private WOWebServiceClient serviceClient() {
        if (_serviceClient == null) {
            _serviceClient = clientFromAddress(_service_address);
        }
        return _serviceClient;
    }
    
    /**
     * Obtains a Web service-client object through which
     * service operations can be invoked.
     * @return Web service-client object.
     */
    private static WOWebServiceClient clientFromAddress(String address) {
        WOWebServiceClient service_client = null;

        // Create the Web service's URL.
        URL url;
        try {
            url = new URL(address);
        }
        catch (MalformedURLException e) {
            url = null;
        }

        // Get a service-client object.
        service_client = new WOWebServiceClient(url);

        return service_client;
    }
}
