//
// Prefix header for all source files of the 'SimpleTabControl' target in the 'SimpleTabControl' project.
//
 
#include <Carbon/Carbon.h>
