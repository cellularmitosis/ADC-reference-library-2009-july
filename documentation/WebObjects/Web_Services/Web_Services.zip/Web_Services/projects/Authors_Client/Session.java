//
// Session.java
// Project Authors_Client
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;

public class Session extends WOSession {

    public Session() {
        super();
        System.out.println("Session created.");
        

    }
    
}
