// Activity.java
// Created on Tue Aug 27 17:15:12 US/Pacific 2002 by Apple EOModeler Version 5.2

package businesslogic.server;

import com.webobjects.foundation.*;
import com.webobjects.eocontrol.*;
import java.math.BigDecimal;
import java.util.*;

public class Activity extends EOGenericRecord {

    public Activity() {
        super();
    }

/*
    // If you implement the following constructor EOF will use it to
    // create your objects, otherwise it will use the default
    // constructor. For maximum performance, you should only
    // implement this constructor if you depend on the arguments.
    public Activity(EOEditingContext context, EOClassDescription classDesc, EOGlobalID gid) {
        super(context, classDesc, gid);
    }

    // If you add instance variables to store property values you
    // should add empty implementions of the Serialization methods
    // to avoid unnecessary overhead (the properties will be
    // serialized for you in the superclass).
    private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
    }

    private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, java.lang.ClassNotFoundException {
    }
*/

    public String name() {
        return (String)storedValueForKey("name");
    }

    public void setName(String value) {
        takeStoredValueForKey(value, "name");
    }

    public String achievements() {
        return (String)storedValueForKey("achievements");
    }

    public void setAchievements(String value) {
        takeStoredValueForKey(value, "achievements");
    }

    public NSTimestamp since() {
        return (NSTimestamp)storedValueForKey("since");
    }

    public void setSince(NSTimestamp value) {
        takeStoredValueForKey(value, "since");
    }

    public businesslogic.server.Student student() {
        return (businesslogic.server.Student)storedValueForKey("student");
    }

    public void setStudent(businesslogic.server.Student value) {
        takeStoredValueForKey(value, "student");
    }
}
