//
// Prefix header for all source files of the 'Rotate Bitmap 90' target in the 'Rotate Bitmap 90' project.
//

#include <Carbon/Carbon.h>
