//
// Session.java
// Project Admissions
//
// Created by bshank on Mon Aug 26 2002
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;

public class Session extends WOSession {

    public Session() {
        super();
        
        /* ** Put your per-session initialization code here ** */
    }
    
    public void clientSideRequestSendRecordViaEmail(EOEnterpriseObject record) {
        String messageSubject, messageBody, message;
        NSMutableArray recipients = new NSMutableArray();
        recipients.addObject("person@foo.com");
        
        Report report = new Report(context());
        report.setStudent(record);
        
        messageSubject = "Student report for " + record.valueForKey("name");
        message = WOMailDelivery.sharedInstance().composeComponentEmail("sender@foo.com",               recipients, null, messageSubject, report, true);
}
    /* not necessary in 5.2
    public boolean distributionContextShouldFollowKeyPath(EODistributionContext                   distributionContext, String path) {
        return (path.equals("session"));
    }
    */
}
