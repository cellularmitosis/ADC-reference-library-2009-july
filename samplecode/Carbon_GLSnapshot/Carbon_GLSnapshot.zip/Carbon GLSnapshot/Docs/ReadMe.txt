Notes:

This demo is designed to demonstrate how to get data out of OpenGL using QuickTime. There are 3 stages to this application at this point - Snapshot, Snapshot Sequence and Movie. At the present time, the Movie portion is not functional due to performance issues with recording the sequences. 