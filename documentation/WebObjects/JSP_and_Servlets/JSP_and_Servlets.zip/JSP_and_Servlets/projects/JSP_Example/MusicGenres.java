//
// MusicGenres.java: Class file for WO Component 'MusicGenres'
// Project JSP_Example
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoaccess.*;

public class MusicGenres extends WOComponent {

    /** @TypeInfo java.lang.String */
    protected NSArray genres;
    public String genre;

    public MusicGenres(WOContext context) {
        super(context);
    }

    public void setGenres(NSArray newGenres)
    {
        genres = newGenres;
    }

}
