//
// Application.java
// Project Security
//

import com.webobjects.appserver.*;
import com.webobjects.foundation.*;

public class Application extends WOApplication {
    
    public static void main(String argv[]) {
        WOApplication.main(argv, Application.class);
    }

    public Application() {
        super();
        System.out.println("Welcome to " + this.name() + "!");
        
        System.out.println();
        
        // Initialize security delegate Web services.
        System.out.println("<Application> Creating SecurityDelegate object");
        SecurityDelegate delegate = new SecurityDelegate();
        
        // Set the security delegate for Web services.
        System.out.println("<Application> Setting security delegate for Web services");
        WOWebServiceRegistrar.setSecurityDelegate(delegate);
        
        // Register Web service.
        WOWebServiceRegistrar.registerWebService(SecureService.class, true);
        
        System.out.println();
    }
}
