//
// FoodInquiry.java: Class file for WO Component 'FoodInquiry'
// Project JSP_Example
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoaccess.*;

public class FoodInquiry extends WOComponent {
    protected String visitorName;
    protected String favoriteFood;

    public FoodInquiry(WOContext context) {
        super(context);
    }

    public String visitorName()
    {
        return visitorName;
    }
    public String favoriteFood()
    {
        return favoriteFood;
    }
    public FavoriteFood showFavoriteFood()
    {
        FavoriteFood nextPage = (FavoriteFood)pageWithName("FavoriteFood");

        // Set the properties of the FavoriteFood component.
        nextPage.setVisitorName(visitorName);
        nextPage.setFavoriteFood(favoriteFood);

        return nextPage;
    }

    public void setFavoriteFood(String newFavoriteFood)
    {
        favoriteFood = newFavoriteFood;
    }

    public void setVisitorName(String newVisitorName)
    {
        visitorName = newVisitorName;
    }

}
