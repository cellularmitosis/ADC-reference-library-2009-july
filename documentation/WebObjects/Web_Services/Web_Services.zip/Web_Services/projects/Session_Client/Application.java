//
// Application.java
// Project Session_Client
//

import com.webobjects.appserver.*;
import com.webobjects.foundation.*;
import com.webobjects.webservices.client.*;

public class Application extends WOApplication {
    
    public static void main(String argv[]) {
        WOApplication.main(argv, Application.class);
    }

    public Application() {
        super();
        System.out.println("Welcome to " + this.name() + "!");
        
        oneClient();
    }

    public void oneClient() {
        // Create the service client used to consume
        // both LogInService and AccessDataService.
        SessionClient sessionClient = new SessionClient();
        
        // Log in as Susana with the password anasus.
        sessionClient.logIn("Susana", "anasus");
        
        // Get session from LogInService.
        WOWebService.SessionInfo sessionInfo = sessionClient.logInSessionInfo();
        
        // Set AccessDataService's session to the one obtained from LogInService.
        sessionClient.setAccessDataSessionInfo(sessionInfo);
        
        // Get values of properties stored in session created by LogInService.
        String userName = sessionClient.userName();
        String userPassword = sessionClient.userPassword();
        
        // Print the properties' values.
        System.out.println();
        System.out.println("************************************************");
        System.out.println("User name from AccessDataService: " + userName);
        System.out.println("User password from AccessDataService: "  + userPassword);
        System.out.println("************************************************");        
        System.out.println();
    }

    public void twoClients() {
        // Create the service client used to consume
        // both LogInService and AccessDataService.
        SessionClient sessionClient1 = new SessionClient();
        
        // Log in as Susana with the password anasus.
        sessionClient1.logIn("Susana", "anasus");
        
        // Get session from LogInService.
        WOWebService.SessionInfo sessionInfo = sessionClient1.logInSessionInfo();
        
        // Create a second service client.
        SessionClient sessionClient2 = new SessionClient();
        
        // Set AccessDataService's session to the one obtained from LogInService.
        sessionClient2.setAccessDataSessionInfo(sessionInfo);
        
        // Get values of properties stored in session created by LogInService.
        String userName = sessionClient2.userName();
        String userPassword = sessionClient2.userPassword();
        
        // Print the properties' values.
        System.out.println();
        System.out.println("************************************************");
        System.out.println("User name from AccessDataService: " + userName);
        System.out.println("User password from AccessDataService: "  + userPassword);
        System.out.println("************************************************");        
        System.out.println();
    }
}
