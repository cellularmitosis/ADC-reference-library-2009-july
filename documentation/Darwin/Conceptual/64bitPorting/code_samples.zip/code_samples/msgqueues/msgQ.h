
#include <sys/types.h>

typedef struct comm_channel {
    int in_fd;
    int out_fd;
    pid_t child_process_id;
} comm_channel;

typedef struct Qmessage
{
    uint8_t message_type;
    uint64_t message_id; // 0 for messages originated locally.
    uint64_t message_length;
    void *message_contents;
    uint64_t response_id;
    uint64_t response_length;
    void *response_contents;
    struct Qmessage *next, *prev;
} Qmessage;

Qmessage *pending;

typedef enum msg_flags {
	MSG_SYNC=0x1,
	MSG_EXPECT_RESPONSE=0x2,
	MSG_MAX=0x80000000
} msg_flags;

enum msg_type {
	msg_type_string = 1,

	_private_INVALID = 254,
	_private_RESPONSE = 255
};

