StickiesExample/Applications Folder

CleanupStickies - use this application to unregister all the Stickies schema clients, unregister the Stickies schema, and remove Note records from the truth. Return the sync engine to the state before you ever ran SimpleStickes or FancyStickies.
 
FancyStickies - companion application for SimpleStickies that uses the same schema. Use FancyStickies to demonstrate multiple syncing clients.

Syncrospector - Sync Services debugging tool used to view the state of clients, sync sessions, schemas, and the sync engine.
 Syncrospector has been updated from the WWDC release to v2.1. Changes were required for the application to run on later Tiger updates, but no UI changes have been made.
