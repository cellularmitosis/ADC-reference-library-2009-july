
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/errno.h>
#include "msgQ.h"
#include "protos.h"

#define APPNAME "msg_recv"

comm_channel *startchild(char *path);

main()
{
    comm_channel chan;
    chan.in_fd = STDIN_FILENO;
    chan.out_fd = STDOUT_FILENO;

    // sleep(10);
    msg_listen(&chan, 1);
}


void handle_response(comm_channel *channel, Qmessage *message)
{
}

char *malloccopy(char *string)
{
	char *buf = malloc(strlen(string)+1);
	strcpy(buf, string);
	return buf;
}

void handle_string(comm_channel *channel, Qmessage *message)
{
	char *returndata = malloccopy("Here's your answer");
	message->response_contents = returndata;
	message->response_length = strlen(returndata)+1;

	fprintf(stderr, "Got message %s\n", message->message_contents);
	msg_reply(channel, message, MSG_SYNC);

        return;
}

#include "shared.c"

