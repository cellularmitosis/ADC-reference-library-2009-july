This iSync document is  a sample that can be used with the iSync Plug-in Maker developer application. This application allows to configure, test and export a plug-in to add iSync support for a SyncML compliant phone.

This document will open in iSync Plug-in Maker. Before being loaded by iSync, it will need to be exported as a plug-in and installed in /Library/PhonePlugins or ~/Library/PhonePlugins.

This sample document illustrates some proposed configuration of a SyncML client nicely behaving with iSync.

