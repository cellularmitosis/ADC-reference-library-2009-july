//
//  JavaClient.java
//  Admissions
//
//  Created by Brent Shank on Mon Aug 26 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

import com.webobjects.appserver.*;

public class JavaClient extends WOComponent {

    public JavaClient(WOContext context) {
        super(context);
    }
}
