<!--

if (parent.frames.length != 0) {
	var frameLink = '<img src="images/hideframes.gif" border="0" alt="Hide Frames">';
}

else {
var frameLink = '<img src="images/showframes.gif" border="0" alt="Show Frames">';}

function testFrame(){
if (parent.frames.length != 0) {
	top.location = self.location;
   // loaded in frames
 }
 else {
 
 location='index2.html';
   // not loaded frames
 }
 }

//-->
