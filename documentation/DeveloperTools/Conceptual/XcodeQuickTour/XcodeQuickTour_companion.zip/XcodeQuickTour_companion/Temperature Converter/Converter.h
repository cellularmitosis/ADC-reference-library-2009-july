//
//  Converter.h
//  Converter
//
//  Copyright 2008, Apple Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Converter : NSObject {
	float fahrenheit;
}

@property(readwrite) float fahrenheit;

- (float) convertToCelsius;

@end
