SwapLAF

This package contains source code and project files for an example of how to dynamically change the look-and-feel for a Swing application among the various PLAF's available on the system.

The project has been updated to work with Xcode 1.5 on Mac OS X Panther.