Surface Vertex Program Demo

This is a vertex program that demonstrates the use of a UV mesh to draw an implicit surface. The UV mesh is bound from -pi to pi and is evaluated on the GPU using the vertex program  SurfaceVertexProgram.vsh (in resources)
	
Use the mouse button and drag to move the object position
The space bar selects the fill mode (lines/quads)
	
In addition the demo can use quicktime to play a sound file from which the 8 equalizer inputs are used to modify the control parameters that define the surface.
	
	