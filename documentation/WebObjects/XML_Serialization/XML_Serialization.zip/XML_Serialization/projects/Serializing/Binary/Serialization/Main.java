//
// Main.java: Class file for WO Component 'Main'
// Project Serialization
//
// Created by ernest on Tue Apr 30 2002
//
 
import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import com.webobjects.eoaccess.*;

public class Main extends WOComponent {

    public Main(WOContext context) {
        super(context);
    }

}
