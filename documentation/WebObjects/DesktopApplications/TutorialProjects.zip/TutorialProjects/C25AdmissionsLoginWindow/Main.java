//
//  Main.java
//  Admissions
//
//  Created by Brent Shank on Mon Aug 26 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//


import com.webobjects.appserver.*;
import com.webobjects.eodistribution.*;

public class Main extends WOComponent {

    public Main(WOContext context) {
        super(context);
    }

    public String javaClientLink() {
        return WOJavaClientComponent.webStartActionURL(context(), "JavaClient");
    }    
}
