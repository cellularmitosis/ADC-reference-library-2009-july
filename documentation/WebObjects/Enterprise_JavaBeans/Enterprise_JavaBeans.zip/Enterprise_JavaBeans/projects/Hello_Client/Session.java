//
// Session.java
// Project Hello_Client
//

import my.ejb.Hello;
import my.ejb.HelloHome;

import java.rmi.RemoteException;
import java.util.Properties;
import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;

public class Session extends WOSession {

    // Holds a Hello bean instance.
    protected Hello hello;
    
    // Holds the Hello bean's home interface.
    private HelloHome _helloHome = null;
    
    
    public Session() {
        super();
        
        // Instantiate a Hello bean object.
        try {
            hello = helloHome().create();
        }
        catch (RemoteException re) {
            re.printStackTrace();
        }
        catch (CreateException ce) {
            ce.printStackTrace();
        }
    }
    
    
    /**
     * Obtains Hello bean's home interface.
     * @retgurn Hello bean's home interface.
     */
    public HelloHome helloHome() {
        if (_helloHome == null) {
            try {
                Context jndiContext = new InitialContext();
                _helloHome = (HelloHome)PortableRemoteObject.narrow(jndiContext.lookup("HelloBean"), HelloHome.class);
            }
            catch (NamingException ne) {
                ne.printStackTrace();
            }
        }
        return _helloHome;
    }
}
