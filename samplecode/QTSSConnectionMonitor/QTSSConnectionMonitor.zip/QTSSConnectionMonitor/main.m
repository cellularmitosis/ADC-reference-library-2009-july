//
//  main.m
//  QTSSConnectionMonitor
//
//  Created by John Anderson on Tue Mar 19 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
