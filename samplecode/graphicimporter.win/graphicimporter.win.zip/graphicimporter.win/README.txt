README - GraphicImporter

GraphicImporter is a sample application that demonstrates ways
of using graphics importers.

Enjoy,
QuickTime Team

