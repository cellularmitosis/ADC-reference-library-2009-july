//
//  LogIn.java
//  Session
//

import org.apache.axis.MessageContext;

import com.webobjects.appserver.*;
import com.webobjects.foundation.*;

/**
 * Implements the LogIn Web service.
 */
public class LogIn {
    public static final String USER_NAME = "userName";
    public static final String USER_PASSWORD = "userPassword";
    
    /**
     * Sets a user's name and password properties in a session.
     */
    public void setUserInfo(String userName, String userPassword) {
        WOSession session = serviceSession();
        session.setObjectForKey(userName, USER_NAME);
        session.setObjectForKey(userPassword, USER_PASSWORD);
    }

    /**
     * Retrieves the session from the current context.
     * @return current context's session.
     */
    private WOSession serviceSession() {
        WOContext context = (WOContext)MessageContext.getCurrentContext().getProperty("com.webobjects.appserver.WOContext");
        WOSession session = context.session();
        return session;
    }
}
