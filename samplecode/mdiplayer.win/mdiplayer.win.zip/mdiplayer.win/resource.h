//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MDIPlayer.rc
//
#define IDS_APPNAME                     1
#define IDS_DESCRIPTION                 2
#define WINDOWMENU                      2
#define IDS_FILTERSTRING                3
#define IDI_APPICON                     101
#define IDI_CHILDICON                   102
#define IDD_ABOUT                       103
#define IDS_FILEMENU                    1000
#define IDM_FILEOPEN                    1002
#define IDM_FILECLOSE                   1005
#define IDM_EXIT                        1008
#define IDS_EDITMENU                    1100
#define IDM_EDITUNDO                    1101
#define IDM_EDITCUT                     1102
#define IDM_EDITCOPY                    1103
#define IDM_EDITPASTE                   1104
#define IDM_EDITCLEAR                   1105
#define IDS_WINDOWMENU                  1300
#define IDM_WINDOWTILE                  1301
#define IDM_WINDOWCASCADE               1302
#define IDM_WINDOWCLOSEALL              1303
#define IDM_WINDOWICONS                 1304
#define IDM_WINDOWCHILD                 1310
#define IDS_HELPMENU                    1400
#define IDM_ABOUT                       1401
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
