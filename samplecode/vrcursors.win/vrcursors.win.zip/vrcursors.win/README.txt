README - VRCursors

VRCursors illustrates how to use the QTVR API to change the default cursors
for specific kinds of hot spots or for specific hot spot IDs.

For Windows builds using Microsoft Visual C++, the Makefile (VRCursors.mak)
automatically calls Rez to create the resource file VRCursors.qtr from the
input file cursors.r. The .qtr file must reside in the same directory as the
application VRCursors.exe. For final delivery of your product, you should insert
the .qtr file into the .exe file by using the tool RezWack.

Enjoy,
QuickTime Team

